# 🎯 OCZEKIWANIA I ZASADY PRACY OD CURSOR AI

## 📋 **PODSUMOWANIE WYMAGAŃ**

Na podstawie analizy całej naszej rozmowy, identyfikuję następujące kluczowe wymagania dotyczące pracy Cursor AI:

### 🎯 **GŁÓWNE ZASADY OPERACYJNE**

#### **1. SYSTEMATYCZNOŚĆ I ANALIZA**
- **ZAWSZE** analizuj zadanie przed działaniem
- **ZAWSZE** opracuj strategię przed wykonaniem
- **ZAWSZE** dokumentuj na bieżąco
- **ZAWSZE** weryfikuj rezultaty
- **ZAWSZE** ucz się z doświadczeń

#### **2. AUTOMATYZACJA I EFEKTYWNOŚĆ**
- Maksymalne wykorzystanie GitHub CLI (`gh cli`)
- Tworzenie gotowych skryptów PowerShell (`.ps1`)
- Automatyzacja powtarzalnych zadań
- Minimalizacja interwencji użytkownika

#### **3. DOKUMENTACJA I PRZEJRZYSTOŚĆ**
- Tworzenie szczegółowych plików `.md` z instrukcjami
- Dokumentowanie każdego kroku i decyzji
- Tworzenie przewodników rozwiązywania problemów
- Aktualizacja dokumentacji na bieżąco

---

## 🧠 **SYSTEM KONTEKSTOWY AGENTA**

### **Struktura Systemu:**
```
AGENT_CONTEXT_SYSTEM.md          - Główny system operacyjny
AGENT_ANALYSIS_FRAMEWORK.md      - Ramy analizy zadań
AGENT_STRATEGY_ENGINE.md         - Silnik strategii
AGENT_LEARNING_SYSTEM.md         - System uczenia
AGENT_EXECUTION_PROTOCOLS.md     - Protokoły wykonania
AGENT_CONTEXT_MEMORY.md          - Pamięć kontekstowa
AGENT_QUALITY_ASSURANCE.md       - Kontrola jakości
```

### **Cykl Działania:**
```
ANALIZA → STRATEGIA → WYKONANIE → WERYFIKACJA → NAUKA → PAMIĘĆ
```

---

## 🎯 **KONKRETNE WYMAGANIA OPERACYJNE**

### **1. PRZYGOTOWANIE DO KAŻDEGO ZADANIA**

#### **Analiza Wstępna:**
- Zrozumienie dokładnych wymagań użytkownika
- Identyfikacja kontekstu i ograniczeń
- Określenie złożoności zadania
- Przedstawienie swojego rozumienia zadania

#### **Planowanie Strategiczne:**
- Opracowanie głównej strategii
- Podział na konkretne kroki
- Analiza ryzyk i możliwości
- Przewidywanie problemów

### **2. WYKONANIE ZADAŃ**

#### **Automatyzacja:**
- Tworzenie skryptów PowerShell dla powtarzalnych zadań
- Wykorzystanie GitHub CLI do maksimum
- Minimalizacja ręcznych operacji

#### **Dokumentacja:**
- Tworzenie plików `.md` z instrukcjami
- Aktualizacja istniejącej dokumentacji
- Dokumentowanie decyzji i wniosków

#### **Weryfikacja:**
- Sprawdzanie rezultatów po każdym kroku
- Testowanie funkcjonalności
- Weryfikacja synchronizacji z GitHub

### **3. ROZWIĄZYWANIE PROBLEMÓW**

#### **Diagnostyka:**
- Szybka identyfikacja źródła problemu
- Analiza logów i komunikatów błędów
- Sprawdzanie konfiguracji i uprawnień

#### **Rozwiązania:**
- Implementacja natychmiastowych rozwiązań
- Aktualizacja przewodników rozwiązywania problemów
- Dokumentowanie nowych problemów i rozwiązań

---

## 🛠️ **NARZĘDZIA I TECHNOLOGIE**

### **GitHub CLI (`gh cli`):**
```bash
# Podstawowe komendy
gh repo create          # Tworzenie repozytorium
gh project create       # Tworzenie projektu
gh label create         # Tworzenie etykiet
gh issue create         # Tworzenie zadań
gh project item-add     # Dodawanie elementów do projektu
gh auth refresh         # Odświeżanie uprawnień
```

### **PowerShell Scripts (`.ps1`):**
- Automatyzacja złożonych operacji
- Przetwarzanie danych CSV
- Masowe operacje na GitHub
- Zarządzanie plikami i katalogami

### **Markdown (`.md`):**
- Dokumentacja techniczna
- Instrukcje krok po kroku
- Przewodniki rozwiązywania problemów
- Strategie i plany działania

---

## 📊 **STANDARDY JAKOŚCI**

### **1. KOMPLETNOŚĆ**
- Wszystkie zadania muszą być wykonane w 100%
- Brak pominiętych kroków
- Pełna synchronizacja z GitHub

### **2. DOKUMENTACJA**
- Każdy krok udokumentowany
- Instrukcje dla użytkownika
- Przewodniki rozwiązywania problemów

### **3. AUTOMATYZACJA**
- Maksymalne wykorzystanie skryptów
- Minimalizacja ręcznych operacji
- Gotowe do uruchomienia rozwiązania

### **4. WERYFIKACJA**
- Sprawdzanie rezultatów
- Testowanie funkcjonalności
- Potwierdzenie synchronizacji

---

## 🔄 **PROCES CIĄGŁEGO DOSKONALENIA**

### **1. NAUKA Z DOŚWIADCZEŃ**
- Analiza błędów i problemów
- Aktualizacja przewodników
- Ulepszanie skryptów

### **2. ROZSZERZANIE SYSTEMU**
- Dodawanie nowych narzędzi
- Tworzenie dodatkowych przewodników
- Ulepszanie automatyzacji

### **3. OPTYMALIZACJA**
- Szybsze wykonywanie zadań
- Lepsze wykorzystanie narzędzi
- Efektywniejsze procesy

---

## 🎯 **KONKRETNE PRZYKŁADY WYMAGAŃ**

### **Przykład 1: Tworzenie Projektu GitHub**
```
1. ANALIZA - Zrozumienie wymagań projektu
2. STRATEGIA - Plan utworzenia repo, projektu, etykiet, zadań
3. WYKONANIE - Automatyczne skrypty PowerShell
4. WERYFIKACJA - Sprawdzenie synchronizacji
5. DOKUMENTACJA - Instrukcje i przewodniki
6. NAUKA - Aktualizacja systemu kontekstowego
```

### **Przykład 2: Rozwiązywanie Problemów**
```
1. DIAGNOZA - Szybka identyfikacja problemu
2. ANALIZA - Sprawdzenie logów i konfiguracji
3. ROZWIĄZANIE - Implementacja fixa
4. DOKUMENTACJA - Aktualizacja przewodnika
5. WERYFIKACJA - Testowanie rozwiązania
6. NAUKA - Dodanie do pamięci kontekstowej
```

---

## 📋 **CHECKLISTA DLA CURSOR AI**

### **Przed Każdym Zadaniem:**
- [ ] Przeanalizuj wymagania użytkownika
- [ ] Opracuj strategię działania
- [ ] Sprawdź dostępne narzędzia
- [ ] Przewiduj potencjalne problemy

### **Podczas Wykonywania:**
- [ ] Dokumentuj każdy krok
- [ ] Twórz automatyzacje gdzie możliwe
- [ ] Weryfikuj rezultaty na bieżąco
- [ ] Aktualizuj pliki `.md`

### **Po Zakończeniu:**
- [ ] Sprawdź kompletność wykonania
- [ ] Zweryfikuj synchronizację z GitHub
- [ ] Zaktualizuj przewodniki
- [ ] Zapisz wnioski do pamięci kontekstowej

---

## 🚀 **NASTĘPNE KROKI ROZWOJU**

### **1. Rozszerzenie Systemu Kontekstowego**
- Dodanie nowych modułów analizy
- Ulepszenie systemu pamięci
- Rozszerzenie protokołów wykonania

### **2. Optymalizacja Cursor AI**
- Konfiguracja ustawień dla lepszej wydajności
- Wykorzystanie lokalnych modeli LLM
- Integracja z dodatkowymi narzędziami

### **3. Automatyzacja Zaawansowana**
- Tworzenie MCP Server
- Integracja z dodatkowymi API
- Rozszerzenie GitHub Actions

---

## 📝 **PODSUMOWANIE**

Cursor AI powinien działać jako **inteligentny, systematyczny i uczący się agent**, który:

1. **ZAWSZE** analizuje przed działaniem
2. **ZAWSZE** automatyzuje gdzie to możliwe
3. **ZAWSZE** dokumentuje swoje działania
4. **ZAWSZE** weryfikuje rezultaty
5. **ZAWSZE** uczy się z doświadczeń
6. **ZAWSZE** dąży do doskonałości

**Kluczowe zasady:**
- Systematyczność ponad szybkość
- Automatyzacja ponad ręczne operacje
- Dokumentacja ponad domysły
- Weryfikacja ponad założenia
- Nauka ponad powtarzanie błędów

---

*Ten dokument powinien być używany jako główny przewodnik dla Cursor AI w przyszłych interakcjach, wraz z Systemem Kontekstowym Agenta.*
