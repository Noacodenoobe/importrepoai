# Skrypt do dodania wszystkich issues do Project Board
Write-Host "📊 Dodawanie issues do Project Board..." -ForegroundColor Cyan

# ID Project Board
$projectNumber = 10

# Dodaj wszystkie issues (1-85)
for ($i = 1; $i -le 85; $i++) {
    Write-Host "🔄 Dodawanie issue #$i do Project Board..." -ForegroundColor Yellow
    
    try {
        $url = "https://github.com/Noacodenoobe/bws-kielce-project/issues/$i"
        gh project item-add $projectNumber --owner Noacodenoobe --url $url
        Write-Host "✅ Dodano issue #$i" -ForegroundColor Green
    } catch {
        Write-Host "❌ Błąd przy dodawaniu issue #$i" -ForegroundColor Red
    }
    
    # Krótka przerwa
    Start-Sleep -Milliseconds 200
}

Write-Host "🎉 Zakończono dodawanie issues do Project Board!" -ForegroundColor Green
Write-Host "📊 Dodano 85 issues do Project Board #$projectNumber" -ForegroundColor Cyan
