# 📋 Manualna Konfiguracja GitHub Project Board

*Szczegółowe instrukcje krok po kroku dla konfiguracji Project Board, gdy automatyzacja CLI nie wystarcza*

## 🎯 Problem do rozwiązania

**Stan aktualny:** Project Board pokazuje tylko 13 zadań zamiast oczekiwanych 85, kolumny "Assignees" i "Status" są puste, brak konfiguracji Kanban.

**Cel:** Skonfigurować Project Board tak, aby wszystkie 85 zadań były widoczne w odpowiednich kolumnach Kanban.

---

## 🔍 Diagnoza problemu

### Krok 1: Sprawdź czy issues są w projekcie

```bash
# Sprawdź ile issues jest w projekcie
gh project item-list 10 --owner Noacodenoobe --limit 100

# Sprawdź wszystkie issues w repozytorium
gh issue list --limit 100 --json number,title
```

**Oczekiwany wynik:** Powinno być 85 issues w projekcie.

### Krok 2: Sprawdź konfigurację kolumn

```bash
# Sprawdź dostępne pola w projekcie
gh project field-list 10 --owner Noacodenoobe

# Sprawdź widoki projektu
gh project view-list 10 --owner Noacodenoobe
```

---

## 🛠️ Rozwiązanie krok po kroku

### Etap 1: Dodanie brakujących issues do projektu

Jeśli w kroku 1 widzisz mniej niż 85 issues, uruchom ponownie skrypt:

```powershell
# Uruchom skrypt dodawania issues
.\add_issues_to_project.ps1
```

### Etap 2: Konfiguracja kolumn Status

**Metoda 1: Przez GitHub CLI (jeśli dostępne)**

```bash
# Sprawdź czy można utworzyć pole Status
gh project field-create 10 --owner Noacodenoobe --name "Status" --data-type "Single select"

# Dodaj opcje do pola Status
gh project field-option-create 10 --owner Noacodenoobe --field-id "Status" --name "Backlog"
gh project field-option-create 10 --owner Noacodenoobe --field-id "Status" --name "To Do"
gh project field-option-create 10 --owner Noacodenoobe --field-id "Status" --name "In Progress"
gh project field-option-create 10 --owner Noacodenoobe --field-id "Status" --name "Done"
gh project field-option-create 10 --owner Noacodenoobe --field-id "Status" --name "Blocked"
```

**Metoda 2: Przez interfejs web (jeśli CLI nie działa)**

1. **Otwórz Project Board:**
   - Przejdź na: https://github.com/users/Noacodenoobe/projects/10
   - Lub: https://github.com/Noacodenoobe/bws-kielce-project/projects/1

2. **Dodaj pole Status:**
   - Kliknij **"Add field"** (prawy górny róg)
   - Wybierz **"Status"**
   - W **"Field type"** wybierz **"Single select"**
   - Kliknij **"Create"**

3. **Dodaj opcje Status:**
   - W nowo utworzonym polu Status kliknij **"Add option"**
   - Dodaj kolejno:
     - `Backlog` (kolor: niebieski)
     - `To Do` (kolor: żółty)
     - `In Progress` (kolor: pomarańczowy)
     - `Done` (kolor: zielony)
     - `Blocked` (kolor: czerwony)

### Etap 3: Konfiguracja widoku Board (Kanban)

1. **Przełącz na widok Board:**
   - W prawym górnym rogu kliknij ikonę **"Board"** (ikona z kartami)
   - Lub wybierz z menu **"View"** → **"Board"**

2. **Skonfiguruj kolumny:**
   - Jeśli kolumny nie są widoczne, kliknij **"Add column"**
   - Dodaj kolumny odpowiadające opcjom Status:
     - `Backlog`
     - `To Do`
     - `In Progress`
     - `Done`
     - `Blocked`

3. **Przypisz Status do kolumn:**
   - Dla każdej kolumny kliknij **"..."** → **"Column settings"**
   - W **"Status"** wybierz odpowiednią opcję

### Etap 4: Automatyzacja przenoszenia zadań

1. **Włącz automatyzację:**
   - Kliknij **"Automation"** (prawy górny róg)
   - Włącz **"Auto-add to project"** dla nowych issues

2. **Skonfiguruj reguły:**
   - **"When an issue is added to the project"** → **"Set status to"** → **"Backlog"**
   - **"When an issue is moved to column"** → **"Set status to"** → **"[nazwa kolumny]"**

### Etap 5: Przypisanie wszystkich issues do kolumny Backlog

**Metoda 1: Przez GitHub CLI**

```bash
# Pobierz listę wszystkich issues w projekcie
gh project item-list 10 --owner Noacodenoobe --limit 100 --json id,content > project_items.json

# Dla każdego issue ustaw status na Backlog
# (To wymaga skryptu PowerShell - patrz poniżej)
```

**Metoda 2: Przez interfejs web**

1. **Przełącz na widok Table:**
   - Kliknij ikonę **"Table"** (ikona z tabelą)

2. **Zaznacz wszystkie issues:**
   - Kliknij checkbox w nagłówku kolumny Title
   - To zaznaczy wszystkie issues

3. **Ustaw status:**
   - W kolumnie Status kliknij dropdown
   - Wybierz **"Backlog"**
   - Kliknij **"Apply"**

### Etap 6: Weryfikacja

1. **Sprawdź liczbę issues:**
   - Powinno być 85 issues w projekcie

2. **Sprawdź widok Board:**
   - Przełącz na widok Board
   - Wszystkie issues powinny być w kolumnie "Backlog"

3. **Sprawdź status:**
   - Każde issue powinno mieć status "Backlog"

---

## 🤖 Automatyzacja przez PowerShell

Jeśli chcesz zautomatyzować proces, utwórz skrypt:

```powershell
# Skrypt do ustawienia statusu dla wszystkich issues
Write-Host "🔄 Ustawianie statusu dla wszystkich issues..." -ForegroundColor Cyan

# Pobierz listę issues w projekcie
$items = gh project item-list 10 --owner Noacodenoobe --limit 100 --json id,content | ConvertFrom-Json

Write-Host "📊 Znaleziono $($items.Count) issues w projekcie" -ForegroundColor Yellow

foreach ($item in $items) {
    $issueNumber = $item.content.number
    Write-Host "🔄 Ustawianie statusu dla issue #$issueNumber..." -ForegroundColor Yellow
    
    # Ustaw status na Backlog
    # Uwaga: To może wymagać GitHub API, jeśli CLI nie obsługuje
    # gh api repos/Noacodenoobe/bws-kielce-project/issues/$issueNumber --field state=open
    
    Start-Sleep -Milliseconds 100
}

Write-Host "✅ Zakończono ustawianie statusów" -ForegroundColor Green
```

---

## 🔧 Rozwiązywanie problemów

### Problem: "Nie mogę dodać pola Status"

**Rozwiązanie:**
- Sprawdź uprawnienia do projektu
- Upewnij się, że jesteś właścicielem lub masz uprawnienia admin
- Spróbuj przez interfejs web zamiast CLI

### Problem: "Issues nie pojawiają się w kolumnach"

**Rozwiązanie:**
- Sprawdź czy automatyzacja jest włączona
- Upewnij się, że kolumny są powiązane z polami Status
- Spróbuj ręcznie przeciągnąć issues do kolumn

### Problem: "Widzę tylko 13 issues zamiast 85"

**Rozwiązanie:**
- Sprawdź czy wszystkie issues zostały dodane do projektu
- Uruchom ponownie skrypt `add_issues_to_project.ps1`
- Sprawdź filtry w widoku

---

## 📋 Checklist weryfikacji

Po wykonaniu wszystkich kroków sprawdź:

- [ ] Project Board zawiera 85 issues
- [ ] Widok Board (Kanban) jest aktywny
- [ ] Kolumny: Backlog, To Do, In Progress, Done, Blocked są widoczne
- [ ] Wszystkie issues mają status "Backlog"
- [ ] Automatyzacja jest włączona
- [ ] Czas ostatniej aktualizacji jest aktualny

---

## 🎯 Oczekiwany rezultat

Po wykonaniu wszystkich kroków Project Board powinien wyglądać tak:

```
[Backlog] [To Do] [In Progress] [Done] [Blocked]
   85       0         0          0       0
```

Wszystkie 85 issues powinny być widoczne w kolumnie "Backlog" i gotowe do przenoszenia między kolumnami w miarę postępu prac.

---

*Instrukcje utworzone na podstawie analizy problemów z projektu BWS Kielce*
*Data: 22.08.2025*
*Wersja: 1.0*
