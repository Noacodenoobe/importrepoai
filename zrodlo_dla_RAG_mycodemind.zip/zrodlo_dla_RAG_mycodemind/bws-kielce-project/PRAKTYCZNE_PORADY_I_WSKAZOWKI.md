# 💡 Praktyczne Porady i Wskazówki - Automatyzacja GitHub Projects

*Sprawdzone metody i najlepsze praktyki z projektów automatyzacji*

## 📋 Spis Treści

1. [Zarządzanie synchronizacją Git/GitHub](#zarządzanie-synchronizacją-gitgithub)
2. [Strategie debugowania w czasie rzeczywistym](#strategie-debugowania-w-czasie-rzeczywistym)
3. [Organizacja plików i struktury projektu](#organizacja-plików-i-struktury-projektu)
4. [Automatyzacja bez błędów](#automatyzacja-bez-błędów)
5. [Monitoring i weryfikacja](#monitoring-i-weryfikacja)
6. [Workflow dla zespołów](#workflow-dla-zespołów)
7. [Narzędzia i komendy ratunkowe](#narzędzia-i-komendy-ratunkowe)

---

## 🔄 Zarządzanie synchronizacją Git/GitHub

### 🎯 Najczęstszy problem: "Wszystko lokalne, nic na GitHub"

**Objawy:**
- Pliki istnieją lokalnie, ale nie widać ich na GitHub
- GitHub pokazuje starą wersję projektu
- Nowe funkcje nie działają online (np. szablony issues, GitHub Actions)

**Przyczyny:**
1. Brak `git add` i `git commit`
2. Brak `git push` po commitach
3. Pliki utworzone w złych katalogach
4. Problemy z narzędziami automatycznymi (edit_file, write)

### ✅ **ZŁOTA REGUŁA**: Zawsze sprawdzaj synchronizację

**Procedura po każdej zmianie:**
```bash
# 1. Sprawdź status
git status

# 2. Dodaj wszystkie zmiany
git add .

# 3. Sprawdź co zostanie commitowane
git status

# 4. Commit z opisem
git commit -m "📝 Opis zmian"

# 5. Wypchnij na GitHub
git push

# 6. Sprawdź online czy zmiany są widoczne
gh repo view --web
```

### 🚨 **Checklist przed zakończeniem pracy**

- [ ] `git status` - sprawdź czy są nieza-commitowane zmiany
- [ ] `git log --oneline -3` - sprawdź ostatnie commity
- [ ] `git push` - wypchnij wszystkie zmiany
- [ ] Otwórz GitHub w przeglądarce i sprawdź wizualnie
- [ ] Przetestuj kluczowe funkcje (szablony, Actions, Project Board)

### 💡 **Porady eksperckie**

**1. Automatyczny push w skryptach:**
```powershell
# Na końcu każdego skryptu automatyzacji
if (Get-Command git -ErrorAction SilentlyContinue) {
    Write-Host "🔄 Synchronizuję z GitHub..." -ForegroundColor Cyan
    git add .
    if (-not (git diff --cached --quiet)) {
        git commit -m "🤖 Automatyczna aktualizacja - $(Get-Date -Format 'HH:mm')"
        git push
        Write-Host "✅ Zmiany wypchnięte na GitHub" -ForegroundColor Green
    } else {
        Write-Host "ℹ️ Brak zmian do commitowania" -ForegroundColor Yellow
    }
}
```

**2. Webhook do weryfikacji:**
```bash
# Dodaj na końcu ważnych skryptów
curl -X POST "https://api.github.com/repos/OWNER/REPO/dispatches" \
  -H "Authorization: token $GITHUB_TOKEN" \
  -d '{"event_type": "verify-sync"}'
```

---

## 🔍 Strategie debugowania w czasie rzeczywistym

### 🎯 Problem: "Nie wiem co się dzieje z moimi plikami"

### ✅ **Metoda "Forensics" - śledztwo plików**

**1. Gdzie są moje pliki?**
```powershell
# Znajdź pliki utworzone w ostatnich 30 minutach
Get-ChildItem -Recurse | Where-Object { 
    $_.LastWriteTime -gt (Get-Date).AddMinutes(-30) 
} | Format-Table Name, Directory, LastWriteTime

# Szukaj po nazwie w całym projekcie
Get-ChildItem -Recurse -Name "*szablon*" -ErrorAction SilentlyContinue
Get-ChildItem -Recurse -Name "*template*" -ErrorAction SilentlyContinue
Get-ChildItem -Recurse -Name "*.md" | Where-Object { $_.Name -like "*task*" }
```

**2. Co zostało zmienione?**
```bash
# Git - co się zmieniło?
git status
git diff
git diff --cached
git log --oneline --since="30 minutes ago"

# Sprawdź niesljedzone pliki
git ls-files --others --exclude-standard
```

**3. Gdzie jestem i gdzie powinienem być?**
```powershell
# Bieżący katalog
Write-Host "Jestem w: $PWD" -ForegroundColor Cyan

# Struktura katalogu
Get-ChildItem | Format-Table Name, Mode

# Czy to repozytorium Git?
if (Test-Path ".git") {
    Write-Host "✅ To jest repozytorium Git" -ForegroundColor Green
    git remote -v
} else {
    Write-Host "❌ To NIE jest repozytorium Git" -ForegroundColor Red
}
```

### 💡 **Debugging w czasie rzeczywistym**

**Template funkcji diagnostycznej:**
```powershell
function Debug-ProjectState {
    Write-Host "`n🔍 DIAGNOZA STANU PROJEKTU" -ForegroundColor Cyan
    Write-Host "=" * 50
    
    # 1. Lokalizacja
    Write-Host "`n📍 LOKALIZACJA:" -ForegroundColor Yellow
    Write-Host "PWD: $PWD"
    Write-Host "Git repo: $(if (Test-Path '.git') { '✅ TAK' } else { '❌ NIE' })"
    
    # 2. Ostatnie pliki
    Write-Host "`n📁 OSTATNIE PLIKI (30 min):" -ForegroundColor Yellow
    Get-ChildItem -Recurse | Where-Object { 
        $_.LastWriteTime -gt (Get-Date).AddMinutes(-30) 
    } | Select-Object Name, Directory | Format-Table
    
    # 3. Status Git
    if (Test-Path '.git') {
        Write-Host "`n📊 STATUS GIT:" -ForegroundColor Yellow
        git status --porcelain
        Write-Host "`nOstatni commit:"
        git log --oneline -1
    }
    
    # 4. GitHub CLI
    Write-Host "`n🌐 GITHUB CLI:" -ForegroundColor Yellow
    try {
        $remote = git remote get-url origin 2>$null
        Write-Host "Remote: $remote"
        Write-Host "Auth status: $(gh auth status 2>&1 | Select-String 'Logged in')"
    } catch {
        Write-Host "❌ Problem z GitHub CLI"
    }
    
    Write-Host "`n" + "=" * 50
}

# Użycie - zawsze kiedy coś nie gra
Debug-ProjectState
```

---

## 📁 Organizacja plików i struktury projektu

### 🎯 Problem: "Pliki tworzą się w złych miejscach"

### ✅ **Strategia "Kontrolowana lokalizacja"**

**1. Zawsze definiuj ścieżki bezwzględne:**
```powershell
# ❌ ŹLE - relatywne ścieżki
$csvPath = "../dokumenty/file.csv"
$scriptPath = "scripts/script.ps1"

# ✅ DOBRZE - bezwzględne ścieżki
$projectRoot = Split-Path -Parent $PSScriptRoot
$csvPath = Join-Path $projectRoot "dokumenty\file.csv"
$repoPath = Join-Path $projectRoot "bws-kielce-project"
$scriptPath = Join-Path $repoPath "scripts\script.ps1"
```

**2. Funkcja pomocnicza do zarządzania ścieżkami:**
```powershell
function Get-ProjectPaths {
    $script:ProjectRoot = Split-Path -Parent $PSScriptRoot
    $script:RepoPath = Join-Path $ProjectRoot "bws-kielce-project"
    $script:DocsPath = Join-Path $ProjectRoot "dokumenty_wstepne"
    $script:ScriptsPath = Join-Path $RepoPath "scripts"
    
    # Sprawdź czy ścieżki istnieją
    @{
        "ProjectRoot" = $ProjectRoot
        "RepoPath" = $RepoPath
        "DocsPath" = $DocsPath
        "ScriptsPath" = $ScriptsPath
    } | ForEach-Object {
        $_.GetEnumerator() | ForEach-Object {
            $exists = Test-Path $_.Value
            Write-Host "$($_.Key): $($_.Value) $(if($exists){'✅'}else{'❌'})" 
        }
    }
    
    return @{
        ProjectRoot = $ProjectRoot
        RepoPath = $RepoPath
        DocsPath = $DocsPath
        ScriptsPath = $ScriptsPath
    }
}

# Użycie na początku każdego skryptu
$paths = Get-ProjectPaths
Set-Location $paths.RepoPath
```

**3. Template skryptu z kontrolą lokalizacji:**
```powershell
#Requires -Version 5.1
param(
    [string]$TargetDirectory = $null
)

# === SEKCJA KONTROLI LOKALIZACJI ===
try {
    # Określ ścieżki
    if ($TargetDirectory) {
        $RepoPath = $TargetDirectory
    } else {
        $ProjectRoot = Split-Path -Parent $PSScriptRoot
        $RepoPath = Join-Path $ProjectRoot "bws-kielce-project"
    }
    
    # Sprawdź czy to repozytorium
    if (-not (Test-Path (Join-Path $RepoPath ".git"))) {
        throw "Katalog nie jest repozytorium Git: $RepoPath"
    }
    
    # Przejdź do repozytorium
    $oldLocation = $PWD
    Set-Location $RepoPath
    Write-Host "✅ Praca w katalogu: $RepoPath" -ForegroundColor Green
    
    # === GŁÓWNA LOGIKA SKRYPTU TUTAJ ===
    
} catch {
    Write-Host "❌ Błąd lokalizacji: $_" -ForegroundColor Red
    exit 1
} finally {
    # Powrót do poprzedniego katalogu
    if ($oldLocation) {
        Set-Location $oldLocation
    }
}
```

---

## 🤖 Automatyzacja bez błędów

### 🎯 Problem: "Skrypty działają raz, a potem się psują"

### ✅ **Strategia "Idempotentność"**

**Każdy skrypt powinien:**
1. Sprawdzać stan przed działaniem
2. Działać poprawnie przy wielokrotnym uruchomieniu
3. Nie psuć się jeśli coś już istnieje

**Template idempotentnego skryptu:**
```powershell
function Create-GitHubLabel {
    param(
        [string]$Name,
        [string]$Color,
        [string]$Description
    )
    
    # Sprawdź czy etykieta już istnieje
    $existingLabel = gh label list --json name | ConvertFrom-Json | 
                     Where-Object { $_.name -eq $Name }
    
    if ($existingLabel) {
        Write-Host "ℹ️ Etykieta '$Name' już istnieje - pomijam" -ForegroundColor Yellow
        return
    }
    
    try {
        gh label create $Name --color $Color --description $Description
        Write-Host "✅ Utworzono etykietę: $Name" -ForegroundColor Green
    } catch {
        Write-Host "❌ Błąd przy tworzeniu etykiety '$Name': $_" -ForegroundColor Red
    }
}

function Create-GitHubIssue {
    param(
        [string]$Title,
        [string]$Body,
        [string[]]$Labels
    )
    
    # Sprawdź czy issue już istnieje
    $existingIssue = gh issue list --search "\"$Title\"" --json title | 
                     ConvertFrom-Json | Where-Object { $_.title -eq $Title }
    
    if ($existingIssue) {
        Write-Host "ℹ️ Issue '$Title' już istnieje - pomijam" -ForegroundColor Yellow
        return
    }
    
    # Utwórz issue
    $labelParams = $Labels | ForEach-Object { "--label", $_ }
    gh issue create --title $Title --body $Body @labelParams
}
```

### 💡 **Strategia "Checkpoint Recovery"**

**Zapisuj postęp i wznów od ostatniego punktu:**
```powershell
# Na początku skryptu
$progressFile = "script-progress.json"
$progress = @{
    labelsCreated = @()
    issuesCreated = @()
    lastStep = ""
}

if (Test-Path $progressFile) {
    $progress = Get-Content $progressFile | ConvertFrom-Json
    Write-Host "📊 Wznawiam od kroku: $($progress.lastStep)" -ForegroundColor Cyan
}

# W trakcie pracy
function Save-Progress {
    param([string]$Step)
    $progress.lastStep = $Step
    $progress | ConvertTo-Json | Out-File $progressFile
}

# Przykład użycia
if ($progress.lastStep -ne "labels-completed") {
    # Twórz etykiety...
    Save-Progress "labels-completed"
}

if ($progress.lastStep -ne "issues-completed") {
    # Twórz issues...
    Save-Progress "issues-completed"
}

# Na końcu - usuń plik postępu
Remove-Item $progressFile -ErrorAction SilentlyContinue
```

---

## 📊 Monitoring i weryfikacja

### 🎯 Problem: "Nie wiem czy wszystko działa"

### ✅ **Strategia "Continuous Verification"**

**1. Sprawdzanie w czasie rzeczywistym:**
```powershell
function Test-GitHubProjectHealth {
    Write-Host "🏥 SPRAWDZANIE ZDROWIA PROJEKTU" -ForegroundColor Cyan
    
    $results = @{}
    
    # Test 1: GitHub CLI
    try {
        gh auth status | Out-Null
        $results.GitHubCLI = "✅ OK"
    } catch {
        $results.GitHubCLI = "❌ BŁĄD: $_"
    }
    
    # Test 2: Repo access
    try {
        gh repo view | Out-Null
        $results.RepoAccess = "✅ OK"
    } catch {
        $results.RepoAccess = "❌ BŁĄD: $_"
    }
    
    # Test 3: Issues count
    try {
        $issueCount = (gh issue list --limit 1000 --json number | ConvertFrom-Json).Count
        $results.IssuesCount = "✅ $issueCount zadań"
    } catch {
        $results.IssuesCount = "❌ BŁĄD: $_"
    }
    
    # Test 4: Labels count
    try {
        $labelCount = (gh label list --json name | ConvertFrom-Json).Count
        $results.LabelsCount = "✅ $labelCount etykiet"
    } catch {
        $results.LabelsCount = "❌ BŁĄD: $_"
    }
    
    # Test 5: Project Board
    try {
        gh project list | Out-Null
        $results.ProjectBoard = "✅ OK"
    } catch {
        $results.ProjectBoard = "❌ BŁĄD: $_"
    }
    
    # Raport
    $results.GetEnumerator() | Sort-Object Key | ForEach-Object {
        Write-Host "$($_.Key): $($_.Value)"
    }
    
    return $results
}

# Uruchom po każdej większej zmianie
Test-GitHubProjectHealth
```

**2. Automatyczne testy w CI/CD:**
```yaml
# .github/workflows/health-check.yml
name: Project Health Check

on:
  push:
    branches: [main]
  schedule:
    - cron: '0 */6 * * *'  # Co 6 godzin

jobs:
  health-check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Test GitHub CLI access
        run: gh auth status
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
      
      - name: Count issues
        run: |
          ISSUE_COUNT=$(gh issue list --limit 1000 --json number | jq length)
          echo "📊 Issues: $ISSUE_COUNT"
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
      
      - name: Test templates
        run: |
          if [ -d ".github/ISSUE_TEMPLATE" ]; then
            TEMPLATE_COUNT=$(find .github/ISSUE_TEMPLATE -name "*.md" | wc -l)
            echo "📋 Templates: $TEMPLATE_COUNT"
          fi
      
      - name: Test automations
        run: |
          if [ -d ".github/workflows" ]; then
            WORKFLOW_COUNT=$(find .github/workflows -name "*.yml" | wc -l)
            echo "🤖 Workflows: $WORKFLOW_COUNT"
          fi
```

---

## 👥 Workflow dla zespołów

### 🎯 Problem: "Jak pracować w zespole nad automatyzacją"

### ✅ **Strategia "Controlled Automation"**

**1. Jedna osoba = jeden obszar:**
```markdown
## Podział odpowiedzialności

👤 **Admin/DevOps**: 
- Konfiguracja repo i Project Board
- GitHub Actions i automatyzacje
- Zarządzanie uprawnieniami

👤 **Koordynator**: 
- Tworzenie i aktualizacja zadań głównych
- Zarządzanie milestone'ami
- Monitoring postępów

👤 **Członkowie zespołu**: 
- Aktualizacja statusów zadań
- Dodawanie komentarzy i postępów
- Tworzenie subtask'ów
```

**2. Shared scripts z logowaniem:**
```powershell
function Log-Action {
    param(
        [string]$Action,
        [string]$User = $env:USERNAME,
        [string]$LogFile = "team-actions.log"
    )
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logEntry = "[$timestamp] $User: $Action"
    
    # Log lokalnie
    $logEntry | Out-File -FilePath $LogFile -Append
    
    # Log w commit message
    git add $LogFile
    git commit -m "📝 $Action by $User" --quiet
}

# Użycie
Log-Action "Utworzono 5 nowych zadań logistycznych"
Log-Action "Zaktualizowano status zadania #23"
```

**3. Template PR dla zmian automatyzacji:**
```markdown
## 🤖 Zmiany w automatyzacji

### Co zostało zmienione?
- [ ] GitHub Actions
- [ ] Szablony issues
- [ ] Etykiety
- [ ] Project Board
- [ ] Skrypty automatyzacji

### Testy wykonane:
- [ ] Lokalne testowanie skryptów
- [ ] Weryfikacja na kopii testowej
- [ ] Sprawdzenie wszystkich ścieżek

### Wpływ na zespół:
- [ ] Nie wymaga działań zespołu
- [ ] Wymaga zaktualizowania dokumentacji
- [ ] Wymaga przeszkolenia zespołu

### Checklist przed merge:
- [ ] Kod przejrzany przez drugą osobę
- [ ] Dokumentacja zaktualizowana
- [ ] Tests passed
- [ ] Backup przygotowany
```

---

## 🆘 Narzędzia i komendy ratunkowe

### 🔧 **Emergency Toolkit**

**1. Szybka diagnoza:**
```bash
# Wszystko w jednej komendzie
echo "=== EMERGENCY DIAGNOSIS ===" && \
echo "PWD: $(pwd)" && \
echo "Git repo: $(if [ -d .git ]; then echo '✅'; else echo '❌'; fi)" && \
echo "GitHub CLI: $(gh auth status 2>&1 | grep -o 'Logged in.*' || echo '❌')" && \
echo "Last commit: $(git log --oneline -1 2>/dev/null || echo 'No commits')" && \
echo "Unstaged files: $(git status --porcelain | wc -l)" && \
echo "Recent files: $(find . -name '*.md' -mmin -30 | wc -l)" && \
echo "=========================="
```

**2. Reset do ostatniego znanego stanu:**
```bash
# Zachowaj zmiany i zresetuj
git stash push -m "Emergency backup $(date)"
git reset --hard HEAD
git clean -fd

# Przywróć zmiany
git stash pop
```

**3. Force sync z GitHub:**
```bash
# Wymuś synchronizację
git add .
git commit -m "🚨 Emergency sync - $(date)"
git push --force-with-lease
```

**4. Odtwórz brakujące pliki:**
```powershell
# Sprawdź co powinno być na GitHub
gh repo view --web

# Porównaj z lokalnym stanem
git ls-files | Sort-Object > local-files.txt
gh api repos/:owner/:repo/contents | jq -r '.[].name' | Sort-Object > github-files.txt
Compare-Object (Get-Content local-files.txt) (Get-Content github-files.txt)

# Usuń pliki tymczasowe
Remove-Item local-files.txt, github-files.txt
```

**5. Szybkie odtworzenie struktury:**
```powershell
# Template do szybkiego odtworzenia
function Restore-ProjectStructure {
    Write-Host "🔧 Odtwarzam strukturę projektu..." -ForegroundColor Cyan
    
    # Podstawowe katalogi
    @(
        ".github/ISSUE_TEMPLATE",
        ".github/workflows",
        "scripts",
        "docs"
    ) | ForEach-Object {
        if (-not (Test-Path $_)) {
            New-Item -Path $_ -ItemType Directory -Force
            Write-Host "📁 Utworzono: $_" -ForegroundColor Green
        }
    }
    
    # Podstawowe pliki
    @(
        @{ Path = "README.md"; Content = "# Projekt BWS Kielce`n`nOpis projektu..." },
        @{ Path = ".gitignore"; Content = "*.log`n*.tmp`nnode_modules/`n.env" }
    ) | ForEach-Object {
        if (-not (Test-Path $_.Path)) {
            $_.Content | Out-File -FilePath $_.Path -Encoding UTF8
            Write-Host "📄 Utworzono: $($_.Path)" -ForegroundColor Green
        }
    }
    
    Write-Host "✅ Struktura projektu odtworzona" -ForegroundColor Green
}
```

---

## 🎯 Podsumowanie najważniejszych zasad

### **TOP 10 ZASAD AUTOMATYZACJI**

1. **Zawsze sprawdzaj synchronizację** - `git status && git push`
2. **Używaj bezwzględnych ścieżek** - unikaj problemów z lokalizacją
3. **Loguj wszystko** - wiedzież co, gdzie i kiedy się stało
4. **Testuj na małych fragmentach** - przed pełną automatyzacją
5. **Rób backup przed zmianami** - `git stash` lub branch
6. **Sprawdzaj wyniki wizualnie** - otwórz GitHub w przeglądarce
7. **Dokumentuj każdą zmianę** - przyszłe ja będzie wdzięczne
8. **Używaj checklist** - żeby nic nie umknęło
9. **Monitoruj na bieżąco** - nie czekaj do końca projektu
10. **Przygotuj plan recovery** - na wypadek gdyby coś poszło nie tak

### **EMERGENCY CONTACTS**

```bash
# Gdy wszystko się psuje:
git stash && git reset --hard HEAD && git clean -fd

# Gdy GitHub CLI nie działa:
gh auth logout && gh auth login

# Gdy nie wiesz gdzie jesteś:
Debug-ProjectState  # (funkcja z tego przewodnika)

# Gdy potrzebujesz pomocy:
gh issue create --title "🚨 POMOC: [opis problemu]" --label help-wanted
```

---

*Przewodnik bazuje na rzeczywistych problemach z projektu BWS Kielce*
*Ostatnia aktualizacja: 22.08.2025*
*Wersja: 1.0*
