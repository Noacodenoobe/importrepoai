# 🌿 BWS Kielce Project
