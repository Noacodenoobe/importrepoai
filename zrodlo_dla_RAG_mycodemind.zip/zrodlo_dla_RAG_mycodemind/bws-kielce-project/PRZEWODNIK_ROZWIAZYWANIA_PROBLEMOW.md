# 🛠️ Przewodnik Rozwiązywania Problemów - Projekt BWS Kielce

*Analiza błędów i rozwiązań z automatyzacji GitHub Project*

## 📋 Spis Treści

1. [Problemy środowiskowe (Windows/PowerShell)](#problemy-środowiskowe)
2. [Błędy GitHub CLI](#błędy-github-cli)
3. [Problemy z ścieżkami plików](#problemy-z-ścieżkami-plików)
4. [Błędy Git i zarządzania plikami](#błędy-git-i-zarządzania-plikami)
5. [Problemy z PowerShell](#problemy-z-powershell)
6. [Optymalizacje i najlepsze praktyki](#optymalizacje-i-najlepsze-praktyki)

---

## 🖥️ Problemy środowiskowe (Windows/PowerShell)

### ❌ Problem 1: Komendy Unix/Linux w PowerShell

**Błąd napotykany:**
```powershell
chmod: The term 'chmod' is not recognized...
bash: The term 'bash' is not recognized...
head: The term 'head' is not recognized...
```

**Przyczyna:** Próba użycia komend Unix/Linux w środowisku Windows PowerShell.

**✅ Rozwiązanie:**
- **Zawsze sprawdzaj środowisko** przed napisaniem skryptów
- **Używaj natywnych komend PowerShell**:
  ```powershell
  # Zamiast chmod +x
  # W PowerShell nie potrzeba nadawać uprawnień wykonywania
  
  # Zamiast head -20
  Get-Content file.txt -Head 20
  
  # Zamiast tail -10  
  Get-Content file.txt -Tail 10
  ```

**🎯 Najlepsza praktyka:**
```powershell
# Sprawdź środowisko na początku skryptu
if ($PSVersionTable.Platform -eq "Win32NT") {
    Write-Host "Środowisko Windows - używam komend PowerShell"
} else {
    Write-Host "Środowisko Unix/Linux - używam komend bash"
}
```

### ❌ Problem 2: Różnice w składni ścieżek

**Błąd napotykany:**
- Mieszanie `/` i `\` w ścieżkach
- Problemy z relatywnymi ścieżkami

**✅ Rozwiązanie:**
```powershell
# Używaj Join-Path dla bezpieczeństwa
$csvPath = Join-Path $PWD "dokumenty_wstepne\BWS_Kielce___Tasks_Master__z_hierarchi__.csv"

# Lub używaj zmiennych środowiskowych
$repoRoot = $PWD
$csvFile = "$repoRoot\dokumenty_wstepne\BWS_Kielce___Tasks_Master__z_hierarchi__.csv"
```

---

## 🔧 Błędy GitHub CLI

### ❌ Problem 3: Nieprawidłowe flagi w komendach gh

**Błędy napotykane:**
```bash
# Błędne użycie
gh project item-add 10 --owner Noacodenoobe --repo bws-kielce-project --issue-number 1-85
# Error: unknown flag: --repo

# Błędne użycie
gh project create "BWS Kielce Project Board" --format json
# Error: required flag(s) "title" not set
```

**✅ Rozwiązania:**

1. **Dodawanie issues do projektu:**
```bash
# ❌ Błędne
gh project item-add 10 --repo bws-kielce-project --issue-number 1

# ✅ Poprawne
gh project item-add 10 --owner Noacodenoobe --url https://github.com/Noacodenoobe/bws-kielce-project/issues/1
```

2. **Tworzenie projektu:**
```bash
# ❌ Błędne
gh project create "BWS Kielce Project Board" --format json

# ✅ Poprawne
gh project create --owner Noacodenoobe --title "BWS Kielce Project Board"
```

**🎯 Najlepsza praktyka:**
```bash
# Zawsze sprawdzaj dokumentację przed użyciem
gh project item-add --help
gh project create --help

# Testuj komendy na pojedynczych elementach przed automatyzacją
```

### ❌ Problem 4: Brak uprawnień GitHub CLI

**Błąd napotykany:**
```
error: your authentication token is missing required scopes [project read:project]
```

**✅ Rozwiązanie:**
```bash
# Odśwież token z wymaganymi uprawnieniami
gh auth refresh -s project,read:project

# Sprawdź status autoryzacji
gh auth status

# Lista wszystkich dostępnych zakresów
gh auth refresh --help
```

**🎯 Prewencja:**
- Zawsze sprawdzaj wymagane uprawnienia na początku projektu
- Dokumentuj wymagane zakresy w README
- Utwórz checklist uprawnień

---

## 📁 Problemy z ścieżkami plików

### ❌ Problem 5: Nieprawidłowe ścieżki względne w skryptach

**Błędy napotykane:**
```powershell
# Skrypt uruchamiany z katalogu nadrzędnego
$csvPath = "../dokumenty_wstepne/BWS_Kielce___Tasks_Master__z_hierarchi__.csv"
# Could not find a part of the path

# Po zmianie katalogu w skrypcie
Set-Location "bws-kielce-project"
$csvPath = "dokumenty_wstepne/BWS_Kielce___Tasks_Master__z_hierarchi__.csv"
# Could not find a part of the path
```

**✅ Rozwiązanie systematyczne:**

1. **Zawsze używaj bezwzględnych ścieżek:**
```powershell
# Zapisz początkowy katalog
$originalPath = $PWD

# Zdefiniuj ścieżki względem katalogu głównego
$projectRoot = Split-Path -Parent $PSScriptRoot
$csvPath = Join-Path $projectRoot "dokumenty_wstepne\BWS_Kielce___Tasks_Master__z_hierarchi__.csv"
$repoPath = Join-Path $projectRoot "bws-kielce-project"

# Sprawdź czy pliki istnieją przed użyciem
if (-not (Test-Path $csvPath)) {
    throw "Nie znaleziono pliku CSV: $csvPath"
}

# Przejdź do katalogu repozytorium
Set-Location $repoPath
```

2. **Funkcja pomocnicza do zarządzania ścieżkami:**
```powershell
function Get-ProjectPath {
    param(
        [string]$RelativePath
    )
    
    $scriptDir = Split-Path -Parent $PSScriptRoot
    $fullPath = Join-Path $scriptDir $RelativePath
    
    if (-not (Test-Path $fullPath)) {
        throw "Ścieżka nie istnieje: $fullPath"
    }
    
    return $fullPath
}

# Użycie
$csvPath = Get-ProjectPath "dokumenty_wstepne\BWS_Kielce___Tasks_Master__z_hierarchi__.csv"
```

### ❌ Problem 6: Skrypty tworzone w złych katalogach

**Problem:** Narzędzie `edit_file` tworzyło pliki w katalogu nadrzędnym zamiast w bieżącym katalogu repozytorium.

**✅ Rozwiązanie:**
```powershell
# Zawsze sprawdzaj bieżący katalog przed utworzeniem pliku
Write-Host "Bieżący katalog: $PWD"

# Dla skryptów PowerShell - skopiuj do właściwego miejsca
if (Test-Path "..\script.ps1") {
    Copy-Item "..\script.ps1" ".\script.ps1"
    Remove-Item "..\script.ps1"
}

# Alternatywnie - użyj bezwzględnych ścieżek
$scriptPath = Join-Path $PWD "script.ps1"
```

---

## 📝 Błędy Git i zarządzania plikami

### ❌ Problem 7: Nie wszystkie pliki są commitowane

**Błędy napotykane:**
```bash
git commit -m "message"
# On branch main, nothing to commit, working tree clean

git status
# nothing to commit, working tree clean
```

**Przyczyna:** Pliki były już commitowane lub nie zostały dodane do staging area.

**✅ Rozwiązanie systematyczne:**

1. **Procedura sprawdzania przed commit:**
```bash
# Sprawdź status
git status

# Sprawdź czy są zmiany w plikach
git diff

# Sprawdź czy są zmiany w staging area
git diff --cached

# Jeśli nie ma zmian, sprawdź historię
git log --oneline -5
```

2. **Procedura dodawania plików:**
```bash
# Dodaj wszystkie nowe pliki
git add .

# Sprawdź co zostało dodane
git status

# Commit tylko jeśli są zmiany
if git diff --cached --quiet; then
    echo "Brak zmian do commitowania"
else
    git commit -m "Opis zmian"
fi
```

### ❌ Problem 8: Problemy z utworzeniem plików przez narzędzia

**Problem:** Pliki utworzone przez `edit_file` nie pojawiały się w oczekiwanych lokalizacjach.

**✅ Rozwiązanie:**
```powershell
# Po użyciu edit_file zawsze sprawdź czy plik został utworzony
$fileName = "new_file.txt"

# Sprawdź w różnych lokalizacjach
$locations = @($PWD, "..", "..\..")
foreach ($location in $locations) {
    $fullPath = Join-Path $location $fileName
    if (Test-Path $fullPath) {
        Write-Host "Znaleziono plik: $fullPath"
        
        # Przenieś do właściwego miejsca jeśli potrzeba
        if ($location -ne $PWD) {
            Move-Item $fullPath (Join-Path $PWD $fileName)
        }
        break
    }
}
```

---

## 💻 Problemy z PowerShell

### ❌ Problem 9: Błędy wykonywania skryptów PowerShell

**Błędy napotykane:**
```
.\script.ps1: The term '.\script.ps1' is not recognized...
```

**Przyczyny:**
1. Skrypt nie istnieje w bieżącym katalogu
2. Polityka wykonywania blokuje skrypt
3. Błąd w ścieżce

**✅ Rozwiązania:**

1. **Sprawdzanie istnienia skryptu:**
```powershell
$scriptName = "script.ps1"

if (Test-Path $scriptName) {
    Write-Host "Skrypt istnieje, uruchamiam..."
    & ".\$scriptName"
} else {
    Write-Host "Skrypt nie istnieje w: $PWD"
    Get-ChildItem *.ps1 | Format-Table Name, Directory
}
```

2. **Sprawdzanie polityki wykonywania:**
```powershell
# Sprawdź bieżącą politykę
Get-ExecutionPolicy

# Ustaw politykę dla bieżącej sesji (jeśli potrzeba)
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope Process
```

### ❌ Problem 10: Niedziałające komendy Select-String

**Problem:** Komendy `Select-String` nie zwracały oczekiwanych wyników lub działały nieprzewidywalnie.

**✅ Rozwiązanie:**
```powershell
# Sprawdź czy plik istnieje
if (-not (Test-Path "README.md")) {
    Write-Host "Plik nie istnieje"
    return
}

# Użyj różnych metod wyszukiwania
$content = Get-Content "README.md"

# Metoda 1: Proste wyszukiwanie
$found = $content | Where-Object { $_ -match "Szybki" }

# Metoda 2: Select-String z pełną ścieżką
$found = Select-String -Path "README.md" -Pattern "Szybki" -SimpleMatch

# Metoda 3: Sprawdzenie zawartości
$fileContent = [System.IO.File]::ReadAllText("README.md")
$contains = $fileContent.Contains("Szybki")

Write-Host "Znaleziono: $contains"
```

---

## 🚀 Optymalizacje i najlepsze praktyki

### 💡 Praktyka 1: Skrypty odporne na błędy

**Template odpornego skryptu PowerShell:**
```powershell
#Requires -Version 5.1

[CmdletBinding()]
param(
    [string]$ProjectRoot = $PWD
)

# Ustawienia ErrorAction
$ErrorActionPreference = "Stop"

try {
    # Sprawdź środowisko
    Write-Host "🔍 Sprawdzanie środowiska..." -ForegroundColor Cyan
    
    # Sprawdź wymagane narzędzia
    $requiredTools = @("gh", "git")
    foreach ($tool in $requiredTools) {
        if (-not (Get-Command $tool -ErrorAction SilentlyContinue)) {
            throw "Wymagane narzędzie nie jest zainstalowane: $tool"
        }
    }
    
    # Sprawdź ścieżki
    $csvPath = Join-Path $ProjectRoot "dokumenty_wstepne\BWS_Kielce___Tasks_Master__z_hierarchi__.csv"
    if (-not (Test-Path $csvPath)) {
        throw "Nie znaleziono pliku CSV: $csvPath"
    }
    
    # Sprawdź autoryzację GitHub
    $authStatus = gh auth status 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw "Brak autoryzacji GitHub CLI. Uruchom: gh auth login"
    }
    
    Write-Host "✅ Wszystkie sprawdzenia zakończone pomyślnie" -ForegroundColor Green
    
    # Główna logika skryptu tutaj...
    
} catch {
    Write-Host "❌ Błąd: $_" -ForegroundColor Red
    Write-Host "📍 Lokalizacja błędu: $($_.ScriptStackTrace)" -ForegroundColor Yellow
    exit 1
} finally {
    # Cleanup jeśli potrzeba
    Set-Location $ProjectRoot
}
```

### 💡 Praktyka 2: Logowanie i debugowanie

```powershell
# Funkcja logowania
function Write-LogMessage {
    param(
        [string]$Message,
        [string]$Level = "INFO"
    )
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $color = switch ($Level) {
        "ERROR" { "Red" }
        "WARNING" { "Yellow" }
        "SUCCESS" { "Green" }
        default { "White" }
    }
    
    Write-Host "[$timestamp] $Level: $Message" -ForegroundColor $color
    
    # Opcjonalnie zapisz do pliku
    "$timestamp $Level: $Message" | Out-File -FilePath "script.log" -Append
}

# Użycie
Write-LogMessage "Rozpoczynam tworzenie podzadań" "INFO"
Write-LogMessage "Znaleziono 63 podzadania" "SUCCESS"
Write-LogMessage "Nie można znaleźć pliku CSV" "ERROR"
```

### 💡 Praktyka 3: Konfiguracja na początku projektu

**Plik konfiguracyjny `project-config.json`:**
```json
{
    "github": {
        "owner": "Noacodenoobe",
        "repo": "bws-kielce-project",
        "requiredScopes": ["project", "read:project", "repo"]
    },
    "paths": {
        "csvFile": "dokumenty_wstepne/BWS_Kielce___Tasks_Master__z_hierarchi__.csv",
        "scriptsDir": "scripts",
        "docsDir": "docs"
    },
    "project": {
        "boardNumber": 10,
        "labelCategories": ["priority", "role", "phase", "status"]
    }
}
```

**Skrypt inicjalizacji:**
```powershell
function Initialize-Project {
    param([string]$ConfigPath = "project-config.json")
    
    if (-not (Test-Path $ConfigPath)) {
        throw "Brak pliku konfiguracyjnego: $ConfigPath"
    }
    
    $config = Get-Content $ConfigPath | ConvertFrom-Json
    
    # Sprawdź GitHub CLI i autoryzację
    Write-Host "🔍 Sprawdzanie GitHub CLI..." -ForegroundColor Cyan
    
    $currentScopes = gh auth status --show-token 2>&1 | Select-String "Token scopes"
    foreach ($scope in $config.github.requiredScopes) {
        if ($currentScopes -notmatch $scope) {
            Write-Host "⚠️ Brak wymaganego zakresu: $scope" -ForegroundColor Yellow
            Write-Host "Uruchom: gh auth refresh -s $($config.github.requiredScopes -join ',')" -ForegroundColor Yellow
        }
    }
    
    # Sprawdź ścieżki
    Write-Host "🔍 Sprawdzanie ścieżek..." -ForegroundColor Cyan
    foreach ($pathKey in $config.paths.PSObject.Properties.Name) {
        $path = $config.paths.$pathKey
        if (-not (Test-Path $path)) {
            Write-Host "⚠️ Brak ścieżki: $pathKey -> $path" -ForegroundColor Yellow
        } else {
            Write-Host "✅ Znaleziono: $pathKey -> $path" -ForegroundColor Green
        }
    }
    
    return $config
}
```

### 💡 Praktyka 4: Testowanie skryptów

```powershell
# Test jednostkowy dla funkcji mapowania priorytetów
function Test-PriorityMapping {
    $testCases = @(
        @{ Input = "Krytyczne"; Expected = "critical" }
        @{ Input = "Wysokie"; Expected = "high" }
        @{ Input = "Normalne"; Expected = "normal" }
        @{ Input = "Niskie"; Expected = "low" }
        @{ Input = "Nieznane"; Expected = "normal" }
    )
    
    foreach ($test in $testCases) {
        $result = Get-PriorityLabel $test.Input
        if ($result -eq $test.Expected) {
            Write-Host "✅ Test passed: $($test.Input) -> $result" -ForegroundColor Green
        } else {
            Write-Host "❌ Test failed: $($test.Input) -> $result (expected: $($test.Expected))" -ForegroundColor Red
        }
    }
}

# Test integracyjny
function Test-GitHubConnection {
    try {
        $repos = gh repo list --limit 1 --json name 2>$null
        if ($repos) {
            Write-Host "✅ Połączenie z GitHub działa" -ForegroundColor Green
            return $true
        }
    } catch {
        Write-Host "❌ Brak połączenia z GitHub" -ForegroundColor Red
        return $false
    }
}
```

---

## 📋 Checklist przed automatyzacją

### ✅ Sprawdzenie środowiska
- [ ] Zidentyfikowany system operacyjny (Windows/Linux/Mac)
- [ ] Sprawdzona wersja PowerShell/Bash
- [ ] Zainstalowane wymagane narzędzia (gh, git)
- [ ] Skonfigurowane uprawnienia GitHub CLI

### ✅ Sprawdzenie struktury projektu  
- [ ] Wszystkie pliki CSV istnieją w oczekiwanych lokalizacjach
- [ ] Struktura katalogów jest zgodna z oczekiwaniami
- [ ] Ścieżki względne są poprawnie zdefiniowane

### ✅ Testowanie komend
- [ ] Przetestowane komendy GitHub CLI na pojedynczych elementach
- [ ] Sprawdzone flagi i parametry
- [ ] Zweryfikowane uprawnienia i zakresy

### ✅ Skrypty
- [ ] Dodano obsługę błędów (try-catch)
- [ ] Sprawdzane są wymagania przed wykonaniem
- [ ] Logowanie postępów i błędów
- [ ] Cleanup w przypadku błędu

### ✅ Po wykonaniu
- [ ] Sprawdzenie czy wszystkie zadania zostały utworzone
- [ ] Weryfikacja etykiet i przypisań
- [ ] Test funkcjonalności Project Board
- [ ] Dokumentacja wykonanych kroków

---

## 🎯 Wnioski i rekomendacje

### 1. **Zawsze najpierw rozpoznaj środowisko**
- Sprawdź system operacyjny
- Zidentyfikuj dostępne narzędzia
- Dostosuj komendy do środowiska

### 2. **Używaj bezwzględnych ścieżek**
- Unikaj relatywnych ścieżek w skryptach
- Sprawdzaj istnienie plików przed użyciem
- Dokumentuj strukturę katalogów

### 3. **Testuj komendy przed automatyzacją**
- Sprawdź pojedyncze komendy GitHub CLI
- Zweryfikuj uprawnienia i zakresy
- Przetestuj na małych zbiorach danych

### 4. **Implementuj solidną obsługę błędów**
- Używaj try-catch we wszystkich skryptach
- Loguj postępy i błędy
- Przewiduj typowe scenariusze awarii

### 5. **Dokumentuj wszystko**
- Zapisuj napotkane błędy i rozwiązania
- Twórz checklisty dla powtarzalnych procesów
- Aktualizuj dokumentację po każdym projekcie

### ❌ Problem 12: Brak Systemu Kontekstowego Agenta (NOWY!)

**Błąd napotykany:**
- Agent nie analizuje zadań przed działaniem
- Brak systematycznego podejścia do problemów
- Brak uczenia się z doświadczeń
- Niespójne działanie między sesjami

**Przyczyna:** Brak kompleksowego systemu kontekstowego, który zapewnia inteligentne działanie agenta.

**✅ Rozwiązanie systematyczne:**

1. **Wdrożenie Systemu Kontekstowego:**
```markdown
# Dodaj do kontekstu agenta następujące pliki:
- AGENT_CONTEXT_SYSTEM.md - Główny system
- AGENT_ANALYSIS_FRAMEWORK.md - Ramy analizy
- AGENT_STRATEGY_ENGINE.md - Silnik strategii
- AGENT_LEARNING_SYSTEM.md - System uczenia
- AGENT_EXECUTION_PROTOCOLS.md - Protokoły wykonania
- AGENT_CONTEXT_MEMORY.md - Pamięć kontekstowa
- AGENT_QUALITY_ASSURANCE.md - Kontrola jakości
```

2. **Procedura dla każdego zadania:**
```markdown
1. ANALIZA - Użyj AGENT_ANALYSIS_FRAMEWORK.md
2. STRATEGIA - Użyj AGENT_STRATEGY_ENGINE.md
3. WYKONANIE - Użyj AGENT_EXECUTION_PROTOCOLS.md
4. WERYFIKACJA - Użyj AGENT_QUALITY_ASSURANCE.md
5. NAUKA - Użyj AGENT_LEARNING_SYSTEM.md
6. PAMIĘĆ - Zapisuj w AGENT_CONTEXT_MEMORY.md
```

3. **Zasady działania:**
```markdown
- ZAWSZE analizuj zadanie przed działaniem
- ZAWSZE opracuj strategię przed wykonaniem
- ZAWSZE dokumentuj na bieżąco
- ZAWSZE weryfikuj rezultaty
- ZAWSZE ucz się z doświadczeń
```

**🎯 Najlepsza praktyka:**
- Używaj systemu kontekstowego w każdej interakcji
- Aktualizuj pamięć kontekstową po każdej sesji
- Wymagaj od agenta analizy przed każdym zadaniem
- Monitoruj jakość działania poprzez system kontroli jakości

---

*Dokument utworzony na podstawie analizy błędów z projektu BWS Kielce*
*Data: 22.08.2025*
*Wersja: 1.1*
