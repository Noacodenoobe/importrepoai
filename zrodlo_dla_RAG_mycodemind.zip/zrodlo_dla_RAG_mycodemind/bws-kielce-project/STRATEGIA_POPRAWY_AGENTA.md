# 🚀 Strategia Poprawy Agenta AI - Mistrzowska Automatyzacja GitHub Projects

*Jak agent AI będzie działał skuteczniej i unikał niedociągnięć w przyszłości*

## 📋 Spis Treści

1. [Wprowadzenie](#wprowadzenie)
2. [Analiza bieżącego problemu (Project Board)](#analiza-bieżącego-problemu-project-board)
3. [Filar 1: Rozszerzona świadomość kontekstu i wizualna weryfikacja](#filar-1-rozszerzona-świadomość-kontekstu-i-wizualna-weryfikacja)
4. [Filar 2: Kompletna strategia konfiguracji](#filar-2-kompletna-strategia-konfiguracji)
5. [Filar 3: Ulepszone zarządzanie plikami i kontekstem](#filar-3-ulepszone-zarządzanie-plikami-i-kontekstem)
6. [Filar 4: Optymalizacja narzędzi i środowiska (Cursor AI)](#filar-4-optymalizacja-narzędzi-i-środowiska-cursor-ai)
7. [Podsumowanie i plan działania](#podsumowanie-i-plan-działania)

---

## 1. Wprowadzenie

Celem tej strategii jest znaczące podniesienie skuteczności działania agenta AI w projektach automatyzacji GitHub, minimalizując ryzyko niedociągnięć i błędów wynikających z niepełnego zrozumienia kontekstu lub oczekiwań użytkownika. Skupimy się na proaktywnym podejściu, weryfikacji wizualnej i dostarczaniu kompleksowych rozwiązań.

## 2. Analiza bieżącego problemu (Project Board)

**Problem:** Pomimo pomyślnego utworzenia repozytorium, issues i dodania ich do Project Board za pomocą `gh cli`, Project Board na GitHubie nie odzwierciedlał tych zmian w sposób oczekiwany przez użytkownika (np. brak widocznych zadań, stary czas aktualizacji).

**Przyczyny:**
*   **Brak wizualnej weryfikacji:** Agent nie ma bezpośredniego dostępu do UI GitHub i nie mógł potwierdzić, czy zmiany są widoczne.
*   **Niejasne domyślne zachowanie GitHub Project Boards:** Nowe Project Boards (Projects (beta)) często wymagają ręcznej konfiguracji kolumn i widoków, aby dodane zadania były widoczne. `gh project item-add` dodaje zadanie do projektu, ale niekoniecznie umieszcza je w konkretnej kolumnie widocznej na tablicy Kanban.
*   **Założenie o kompletności automatyzacji:** Agent założył, że samo dodanie elementów do projektu jest wystarczające, nie uwzględniając etapu wizualizacji.

## 3. Filar 1: Rozszerzona świadomość kontekstu i wizualna weryfikacja

Aby uniknąć podobnych problemów, agent musi aktywnie dążyć do zrozumienia oczekiwanego stanu wizualnego i proaktywnie weryfikować wyniki.

### 3.1. Proaktywne pytania o oczekiwany stan UI

Po każdej operacji, która ma wpływ na interfejs użytkownika (np. utworzenie Project Board, dodanie issues), agent powinien zadawać pytania weryfikujące:
*   "Czy widzisz nowo utworzony Project Board na liście projektów?"
*   "Czy po otwarciu Project Board widzisz kolumny 'Backlog', 'To Do', 'In Progress', 'Done'?"
*   "Czy zadania (issues) są widoczne w kolumnie 'Backlog' lub innej domyślnej?"
*   "Jaki jest aktualny czas ostatniej aktualizacji Project Board na GitHubie?"

### 3.2. Wykorzystanie zrzutów ekranu do debugowania

Zrzuty ekranu dostarczone przez użytkownika są bezcennym źródłem informacji. Agent powinien:
*   **Aktywnie prosić o zrzuty ekranu** w przypadku problemów z wizualizacją lub niezgodnościami.
*   **Analizować zrzuty ekranu** pod kątem konkretnych elementów UI (np. nazwy kolumn, liczba elementów, czas ostatniej aktualizacji, widoczne filtry).
*   **Porównywać stan UI** ze stanem oczekiwanym i wynikami komend CLI.

### 3.3. Symulacja interakcji z UI (jeśli to możliwe)

Chociaż agent nie ma bezpośredniego dostępu do UI, może "symulować" kroki, które użytkownik musiałby wykonać, aby zweryfikować stan:
*   "Proszę, przejdź na stronę Project Board na GitHubie."
*   "Sprawdź, czy w ustawieniach Project Board są zdefiniowane kolumny."
*   "Upewnij się, że widok jest ustawiony na 'Board' (Kanban)."

## 4. Filar 2: Kompletna strategia konfiguracji

Automatyzacja musi obejmować wszystkie aspekty konfiguracji, które są możliwe do wykonania za pomocą CLI, oraz dostarczać jasne instrukcje dla kroków manualnych.

### 4.1. Domyślne konfiguracje GitHub Projects

Agent powinien mieć wbudowaną wiedzę o domyślnych konfiguracjach GitHub Projects (Projects (beta)), w tym o tym, że:
*   Nowe projekty często startują z pustą tablicą lub minimalnymi kolumnami.
*   Issues dodane za pomocą `gh project item-add` domyślnie trafiają do "No status" lub pierwszej dostępnej kolumny, jeśli jest skonfigurowana automatyzacja.
*   Wymagane jest ręczne dodanie kolumn (np. Backlog, To Do, In Progress, Done) i ewentualnie automatyzacji przenoszenia zadań.

### 4.2. Generowanie skryptów do konfiguracji kolumn/widoków

Jeśli GitHub CLI oferuje komendy do zarządzania kolumnami Project Board (np. `gh project field create`, `gh project view create`), agent powinien generować skrypty do ich automatycznego tworzenia. Jeśli nie, powinien jasno to komunikować.

### 4.3. Instrukcje dla manualnych kroków

Dla każdego kroku, którego nie da się zautomatyzować (np. dodanie kolumn w UI, konfiguracja automatyzacji przenoszenia kart), agent powinien dostarczyć:
*   **Szczegółowe instrukcje krok po kroku** (np. "Kliknij 'Add field', wybierz 'Status', dodaj opcje 'Backlog', 'To Do'").
*   **Zrzuty ekranu (jeśli dostarczone przez użytkownika)** lub opisy, które pomogą użytkownikowi wizualnie zidentyfikować elementy.
*   **Oczekiwany rezultat** po wykonaniu manualnego kroku.

## 5. Filar 3: Ulepszone zarządzanie plikami i kontekstem

Problemy z synchronizacją Git i lokalizacją plików były powtarzające się. Agent musi wzmocnić swoje procedury w tym zakresie.

### 5.1. Weryfikacja ścieżek plików po każdej operacji

Po każdej operacji tworzenia/modyfikacji pliku, agent powinien:
*   **Potwierdzić istnienie pliku** w oczekiwanej lokalizacji (`Test-Path`).
*   **Potwierdzić zawartość pliku** (`Get-Content`).
*   **Upewnić się, że plik znajduje się w repozytorium Git**, jeśli ma być synchronizowany.

### 5.2. Automatyczne commitowanie i pushowanie po kluczowych zmianach

Po każdej grupie logicznych zmian (np. utworzenie szablonów issues, konfiguracja GitHub Actions, aktualizacja dokumentacji), agent powinien:
*   **Automatycznie wykonać `git add .`**
*   **Automatycznie wykonać `git commit -m "Opis zmian"`**
*   **Automatycznie wykonać `git push`**
*   **Potwierdzić sukces operacji `git push`**.

### 5.3. Struktura plików dla "RAG" agenta

Aby agent działał "po mistrzowsku" w przyszłości, potrzebuje zorganizowanej bazy wiedzy. Proponowana struktura plików w repozytorium:

```
.
├── .github/
│   ├── ISSUE_TEMPLATE/
│   ├── workflows/
│   └── labeler.yml
├── dokumenty_wstepne/
│   └── BWS_Kielce___Tasks_Master__z_hierarchi__.csv
├── scripts/
│   ├── create_all_subtasks.ps1
│   ├── add_issues_to_project.ps1
│   └── ... (inne skrypty automatyzacji)
├── docs/
│   ├── PRZEWODNIK_ROZWIAZYWANIA_PROBLEMOW.md
│   ├── PRAKTYCZNE_PORADY_I_WSKAZOWKI.md
│   ├── STRATEGIA_DALSZYCH_DZIALAN.md
│   ├── AGENT_IMPROVEMENT_STRATEGY.md  <-- Nowy plik
│   └── MANUAL_PROJECT_BOARD_SETUP.md  <-- Nowy plik z instrukcjami manualnymi
├── README.md
└── .gitignore
```

**Nowe pliki:**
*   `AGENT_IMPROVEMENT_STRATEGY.md`: Ten plik, który właśnie tworzę, będzie zawierał strategię poprawy działania agenta.
*   `MANUAL_PROJECT_BOARD_SETUP.md`: Plik zawierający szczegółowe instrukcje krok po kroku dla manualnej konfiguracji Project Board (np. dodawanie kolumn, ustawianie automatyzacji, tworzenie widoków), jeśli nie da się tego zrobić przez CLI.

Te pliki, dodane do kontekstu, pozwolą agentowi na szybsze odwoływanie się do sprawdzonych procedur i strategii.

## 6. Filar 4: Optymalizacja narzędzi i środowiska (Cursor AI)

### 6.1. Ustawienia Cursor AI

Aby agent działał optymalnie, należy sprawdzić i dostosować ustawienia Cursor AI:
*   **Context Window Size:** Upewnić się, że rozmiar okna kontekstowego jest wystarczająco duży, aby pomieścić wszystkie istotne pliki i historię rozmowy. Zbyt małe okno kontekstowe może prowadzić do "zapominania" wcześniejszych instrukcji lub stanu projektu.
*   **File Indexing/Embedding:** Sprawdzić, czy wszystkie istotne pliki (zwłaszcza nowe pliki `.md` z poradami i strategiami) są prawidłowo indeksowane i dostępne dla modelu.
*   **Tool Usage Configuration:** Upewnić się, że agent ma dostęp do wszystkich niezbędnych narzędzi (terminal, edycja plików, czytanie plików) i że ich użycie jest priorytetyzowane w odpowiednich scenariuszach.
*   **Model Selection:** Jeśli dostępne są różne modele, eksperymentować z tymi, które lepiej radzą sobie z długim kontekstem i złożonym rozumowaniem.

### 6.2. Potencjał lokalnych modeli i niestandardowych agentów

*   **Lokalne modele:** Działanie na modelu lokalnym na Twoim sprzęcie może mieć sens, jeśli:
    *   Potrzebna jest większa prywatność danych.
    *   Chcesz uniknąć opóźnień związanych z API.
    *   Możesz dostosować model (fine-tuning) do specyficznych zadań i Twojego stylu pracy, co może poprawić "zrozumienie" Twoich potrzeb.
    *   Wymaga to jednak odpowiedniej mocy obliczeniowej i wiedzy technicznej do zarządzania modelem.
*   **Dostosowany agent:** Stworzenie niestandardowego agenta, który jest specjalnie przeszkolony lub skonfigurowany do pracy z GitHub CLI i Twoimi preferencjami, może być bardzo skuteczne. Taki agent mógłby mieć wbudowane "checklisty" weryfikacji UI, specyficzne procedury debugowania dla GitHub Projects i głębsze zrozumienie Twojego workflow.

### 6.3. Koncepcja "MCP Server"

Koncepcja "MCP Server" (Master Control Program Server) jest interesująca, ale na obecnym etapie, skupiłbym się na optymalizacji interakcji z GitHub i lokalnym środowiskiem. Taki serwer mógłby być rozważany w przyszłości, jeśli projekt rozrośnie się do bardzo złożonych integracji wymagających centralnego zarządzania wieloma usługami i agentami. Na razie, priorytetem jest opanowanie podstawowej automatyzacji i weryfikacji.

## 7. Podsumowanie i plan działania

1.  **Natychmiastowe debugowanie Project Board:**
    *   Zweryfikuję, czy issues zostały faktycznie dodane do Project Board za pomocą `gh project item-list`.
    *   Jeśli tak, poprowadzę Cię przez manualną konfigurację kolumn i widoków na GitHubie, aby zadania stały się widoczne.
    *   Jeśli nie, ponownie uruchomię skrypt `add_issues_to_project.ps1` i zweryfikuję jego działanie.
2.  **Wdrożenie strategii poprawy agenta:**
    *   Ten plik (`AGENT_IMPROVEMENT_STRATEGY.md`) zostanie dodany do repozytorium.
    *   Utworzę plik `MANUAL_PROJECT_BOARD_SETUP.md` z instrukcjami dla manualnej konfiguracji Project Board.
    *   Będę aktywnie stosował zasady wizualnej weryfikacji i proaktywnych pytań.
    *   Będę dążył do automatycznego commitowania i pushowania po każdej logicznej grupie zmian.
3.  **Rekomendacje dla Cursor AI:**
    *   Zasugeruję sprawdzenie ustawień Cursor AI (context window, indexing).
    *   Będę otwarty na dyskusję o lokalnych modelach i niestandardowych agentach w przyszłości.

Ta strategia ma na celu przekształcenie obecnych wyzwań w cenne lekcje, które pozwolą mi działać znacznie sprawniej i bardziej intuicyjnie w przyszłości.
