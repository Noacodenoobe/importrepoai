---
name: 🛒 Zadanie Zakupowe
about: Utwórz zadanie związane z zakupami
title: "[ZAKUPY] "
labels: ["purchases"]
assignees: []
---

## 🛒 Zadanie Zakupowe

**Dostawca**: [NAZWA]
**Budżet**: [KWOTA]
**Termin dostawy**: [DATA]

### Produkty
- [ ] Produkt 1 - Ilość: [X] - Cena: [Y]
- [ ] Produkt 2 - Ilość: [X] - Cena: [Y]

### Kontakt
**Telefon**: [NUMER]
**Email**: [EMAIL]

### Status zamówienia
- [ ] Kontakt z dostawcą
- [ ] Wycena otrzymana
- [ ] Zamówienie złożone
- [ ] Potwierdzenie dostawy
- [ ] Dostawa otrzymana

### Uwagi
[DODATKOWE INFORMACJE]
