### Mapa Zadań (Action Items)
| Zadanie                 | Kto?           | Kiedy?     | Priorytet |
|-------------------------|----------------|------------|-----------|
| Przygotować środowisko  | Jan Kowalski   | 2024-09-01 | Wysoki    |
| Skonfigurować Whisper   | Anna Nowak     | 2024-09-03 | Średni    |
| Testy integracyjne      |                | 2024-09-10 | Niski     |
