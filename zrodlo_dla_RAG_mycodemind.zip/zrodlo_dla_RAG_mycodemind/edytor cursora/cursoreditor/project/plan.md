# Plan rozwoju projektu

1. Konwersja Action Items z Markdown do JSON
2. Automatyczny import zadań do GitHub Projects
3. Modularny dobór promptów i modeli LLM pod zadanie (streszczenia, ekstrakcja, klasyfikacja)
4. Interfejs do zarządzania workflow (np. przez n8n lub Streamlit)
5. Integracja z Obsidian jako "drugi mózg" projektu