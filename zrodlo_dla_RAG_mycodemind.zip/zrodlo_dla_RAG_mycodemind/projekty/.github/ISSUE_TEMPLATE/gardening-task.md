---
name: 🌿 Zadanie Ogrodnicze
about: Utwórz zadanie związane z ogrodnictwem
title: "[OGRODNICTWO] "
labels: ["gardening"]
assignees: []
---

## 🌿 Zadanie Ogrodnicze

**Lokalizacja**: [MIEJSCE]
**Data**: [DATA]
**Typ roślin**: [RODZAJ]

### Rośliny potrzebne
- [ ] Roślina 1 - Ilość: [X] - Rozmiar: [Y]
- [ ] Roślina 2 - Ilość: [X] - Rozmiar: [Y]

### Podłoże i nawozy
- [ ] Podłoże - Ilość: [X]
- [ ] Nawóz - Ilość: [X]

### Etapy pracy
- [ ] Przygotowanie podłoża
- [ ] Sadzenie roślin
- [ ] Podlewanie
- [ ] Nawożenie
- [ ] Przycinanie

### Warunki środowiskowe
**Temperatura**: [X°C]
**Wilgotność**: [X%]
**Oświetlenie**: [TYP]

### Uwagi
[DODATKOWE INFORMACJE]
