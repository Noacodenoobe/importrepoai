---
name: 🚚 Zadanie Logistyczne
about: Utwórz zadanie związane z logistyką
title: "[LOGISTYKA] "
labels: ["logistics"]
assignees: []
---

## 🚚 Zadanie Logistyczne

**Trasa**: [OD] → [DO]
**Data**: [DATA]
**Pojazd**: [TYP]

### Lista przewożonych rzeczy
- [ ] Rzecz 1
- [ ] Rzecz 2

### Harmonogram
- [ ] Godzina wyjazdu: [XX:XX]
- [ ] Godzina przyjazdu: [XX:XX]

### Status transportu
- [ ] Planowanie trasy
- [ ] Rezerwacja pojazdu
- [ ] Pakowanie
- [ ] W drodze
- [ ] Dostarczone

### Kontakt kierowcy
**Telefon**: [NUMER]
**Email**: [EMAIL]

### Uwagi
[DODATKOWE INFORMACJE]
