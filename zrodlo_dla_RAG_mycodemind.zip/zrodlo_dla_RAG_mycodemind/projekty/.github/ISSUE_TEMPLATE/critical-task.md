---
name: 🚨 Zadanie Krytyczne
about: Utwórz zadanie o wysokim priorytecie
title: "[KRYTYCZNE] "
labels: ["critical"]
assignees: []
---

## 🚨 Zadanie Krytyczne

**Priorytet**: Krytyczny
**Deadline**: [DATA]
**Osoba odpowiedzialna**: [IMIĘ]

### Opis
[OPIS ZADANIA]

### Wymagania
- [ ] Wymaganie 1
- [ ] Wymaganie 2

### Zależności
- [ ] Zależność 1
- [ ] Zależność 2

### Kryteria ukończenia
- [ ] Kryterium 1
- [ ] Kryterium 2

### Uwagi
[DODATKOWE INFORMACJE]
