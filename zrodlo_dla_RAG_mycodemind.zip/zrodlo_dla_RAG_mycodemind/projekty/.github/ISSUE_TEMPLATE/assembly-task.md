---
name: 🔧 Zadanie Montażowe
about: Utwórz zadanie związane z montażem
title: "[MONTAŻ] "
labels: ["assembly"]
assignees: []
---

## 🔧 Zadanie Montażowe

**Lokalizacja**: [MIEJSCE]
**Data**: [DATA]
**Zespół**: [OSOBY]

### Narzędzia potrzebne
- [ ] Narzędzie 1
- [ ] Narzędzie 2

### Materiały
- [ ] Materiał 1 - Ilość: [X]
- [ ] Materiał 2 - Ilość: [X]

### Etapy montażu
- [ ] Przygotowanie stanowiska
- [ ] Montaż elementu 1
- [ ] Montaż elementu 2
- [ ] Testowanie
- [ ] Finalizacja

### Bezpieczeństwo
- [ ] Sprawdzenie sprzętu
- [ ] Instrukcje BHP
- [ ] Odzież ochronna

### Uwagi
[DODATKOWE INFORMACJE]
