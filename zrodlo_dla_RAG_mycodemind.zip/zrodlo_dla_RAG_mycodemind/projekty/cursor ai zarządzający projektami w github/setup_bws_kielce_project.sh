#!/bin/bash

# 🌿 BWS Kielce Project - Automatyczna konfiguracja
# =================================================

echo "🚀 Rozpoczynam automatyczną konfigurację projektu BWS Kielce..."
echo "================================================================"

# Sprawdź czy GitHub CLI jest zainstalowany
if ! command -v gh &> /dev/null; then
    echo "❌ GitHub CLI nie jest zainstalowany. Zainstaluj go z: https://cli.github.com/"
    exit 1
fi

# Sprawdź czy użytkownik jest zalogowany
if ! gh auth status &> /dev/null; then
    echo "❌ Nie jesteś zalogowany do GitHub CLI. Uruchom: gh auth login"
    exit 1
fi

echo "✅ GitHub CLI jest gotowy!"

# KROK 1: Utwórz repozytorium i projekt
echo ""
echo "📋 KROK 1: Tworzenie repozytorium i projektu..."
echo "================================================"
bash step1_create_repository_and_project.sh

if [ $? -ne 0 ]; then
    echo "❌ Błąd podczas tworzenia repozytorium i projektu"
    exit 1
fi

# Przejdź do katalogu repozytorium
cd bws-kielce-project

# KROK 2: Utwórz etykiety
echo ""
echo "📋 KROK 2: Tworzenie etykiet..."
echo "================================"
bash ../step2_create_labels.sh

if [ $? -ne 0 ]; then
    echo "❌ Błąd podczas tworzenia etykiet"
    exit 1
fi

# KROK 3: Utwórz główne zadania
echo ""
echo "📋 KROK 3: Tworzenie głównych zadań..."
echo "======================================"
bash ../step3_create_issues.sh

if [ $? -ne 0 ]; then
    echo "❌ Błąd podczas tworzenia głównych zadań"
    exit 1
fi

# KROK 3B: Utwórz podzadania
echo ""
echo "📋 KROK 3B: Tworzenie podzadań..."
echo "=================================="
bash ../step3b_create_subtasks.sh

if [ $? -ne 0 ]; then
    echo "❌ Błąd podczas tworzenia podzadań"
    exit 1
fi

# Utwórz README.md
echo ""
echo "📝 Tworzenie README.md..."
cat > README.md << 'EOF'
# 🌿 BWS Kielce Project

System zarządzania projektem dekoracji ogrodowych dla BWS Kielce.

## 📊 Struktura projektu

### Zadania (Issues)
- **Główne zadania**: 21 zadań nadrzędnych
- **Podzadania**: Szczegółowe kroki dla każdego głównego zadania
- **Etykiety**: Priorytet, rola, etap, status

### Etykiety (Labels)

#### Priorytet
- `critical` - Zadania krytyczne
- `high` - Zadania wysokiego priorytetu  
- `normal` - Zadania normalnego priorytetu
- `low` - Zadania niskiego priorytetu

#### Rola
- `coordination` - Zadania koordynacyjne
- `purchases` - Zadania zakupowe
- `logistics` - Zadania logistyczne
- `assembly` - Zadania montażowe
- `gardening` - Zadania ogrodnicze

#### Etap
- `planning` - Etap planowania (22-23.08)
- `preparation` - Etap przygotowań (24-29.08)
- `execution` - Etap wykonania (30-31.08)
- `completion` - Etap zakończenia (01.09)

#### Status
- `blocked` - Zadanie zablokowane
- `waiting` - Oczekujące na akcję
- `ready` - Gotowe do wykonania

## 🎯 Harmonogram

- **22-23.08.2025**: Planowanie
- **24-29.08.2025**: Przygotowania
- **30-31.08.2025**: Wykonanie
- **01.09.2025**: Zakończenie

## 📋 Codzienna checklista

1. Sprawdź zadania z etykietą `critical`
2. Przejrzyj zadania na dziś (według daty)
3. Zaktualizuj status zadań w toku
4. Sprawdź blokady i zależności

## 🔗 Przydatne linki

- [GitHub Project Board](https://github.com/orgs/[USERNAME]/projects/[PROJECT_NUMBER])
- [Wszystkie zadania](https://github.com/[USERNAME]/bws-kielce-project/issues)
- [Dokumentacja projektu](link-do-dokumentacji)

## 📞 Kontakt

- **Koordynacja**: koordynacja@projekt.pl
- **Zakupy**: zakupy@projekt.pl
- **Logistyka**: logistyka@projekt.pl
- **Montaż**: montaz@projekt.pl
- **Ogrodnictwo**: ogrodnictwo@projekt.pl
EOF

# Dodaj README do repozytorium
git add README.md
git commit -m "📝 Dodaj README z opisem projektu"
git push origin main

echo ""
echo "🎉 KONFIGURACJA ZAKOŃCZONA POMYŚLNIE!"
echo "======================================"
echo ""
echo "✅ Utworzono repozytorium: bws-kielce-project"
echo "✅ Utworzono projekt GitHub"
echo "✅ Utworzono wszystkie etykiety"
echo "✅ Utworzono 21 głównych zadań"
echo "✅ Utworzono 65 podzadań"
echo "✅ Utworzono README.md"
echo ""
echo "🌐 Otwórz projekt w przeglądarce:"
echo "   https://github.com/$(gh api user --jq .login)/bws-kielce-project"
echo ""
echo "📊 Otwórz GitHub Project:"
echo "   https://github.com/orgs/$(gh api user --jq .login)/projects"
echo ""
echo "🎯 Następne kroki:"
echo "   1. Skonfiguruj kolumny Kanban w GitHub Project"
echo "   2. Dodaj członków zespołu do repozytorium"
echo "   3. Ustaw powiadomienia i automatyzacje"
echo "   4. Rozpocznij pracę nad zadaniami!"
echo ""
echo "🚀 Projekt jest gotowy do użycia!"
