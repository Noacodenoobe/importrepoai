#!/bin/bash

# KROK 2: Stwórz Etykiety (Labels)
# =================================

echo "🏷️ Tworzenie etykiet dla projektu BWS Kielce..."

# Priorytet - Labels
echo "📊 Tworzenie etykiet priorytetu..."
gh label create "critical" --color "#FF0000" --description "Zadania krytyczne - najwyższy priorytet"
gh label create "high" --color "#FF6B35" --description "Zadania wysokiego priorytetu"
gh label create "normal" --color "#4ECDC4" --description "Zadania normalnego priorytetu"
gh label create "low" --color "#95A5A6" --description "Zadania niskiego priorytetu"

# Rola - Labels
echo "👥 Tworzenie etykiet ról..."
gh label create "coordination" --color "#3498DB" --description "Zadania koordynacyjne"
gh label create "purchases" --color "#E74C3C" --description "Zadania zakupowe"
gh label create "logistics" --color "#F39C12" --description "Zadania logistyczne"
gh label create "assembly" --color "#27AE60" --description "Zadania montażowe"
gh label create "gardening" --color "#8E44AD" --description "Zadania ogrodnicze"

# Etap - Labels
echo "📋 Tworzenie etykiet etapów..."
gh label create "planning" --color "#1ABC9C" --description "Etap planowania"
gh label create "preparation" --color "#F1C40F" --description "Etap przygotowań"
gh label create "execution" --color "#E67E22" --description "Etap wykonania"
gh label create "completion" --color "#9B59B6" --description "Etap zakończenia"

# Status - Labels
echo "🔄 Tworzenie etykiet statusu..."
gh label create "blocked" --color "#E74C3C" --description "Zadanie zablokowane"
gh label create "waiting" --color "#F39C12" --description "Oczekujące na akcję"
gh label create "ready" --color "#27AE60" --description "Gotowe do wykonania"

# Dodatkowe etykiety specyficzne dla projektu
echo "🎯 Tworzenie dodatkowych etykiet..."
gh label create "milestone" --color "#34495E" --description "Kamień milowy projektu"
gh label create "documentation" --color "#16A085" --description "Dokumentacja"
gh label create "quality-check" --color "#D35400" --description "Kontrola jakości"
gh label create "client-communication" --color "#8E44AD" --description "Komunikacja z klientem"

echo "✅ Wszystkie etykiety zostały utworzone!"
echo "🎯 Krok 2 zakończony pomyślnie!"
