# Skrypt do konfiguracji GitHub Project Board
Write-Host "📊 Konfiguracja GitHub Project Board..." -ForegroundColor Cyan

Write-Host "🔐 Sprawdzenie uprawnień..." -ForegroundColor Yellow
Write-Host "Uruchom: gh auth refresh -s project,read:project" -ForegroundColor Red
Write-Host "Następnie uruchom ten skrypt ponownie." -ForegroundColor Yellow

# Instrukcje konfiguracji Project Board
Write-Host ""
Write-Host "📋 INSTRUKCJE KONFIGURACJI PROJECT BOARD:" -ForegroundColor Green
Write-Host "==========================================" -ForegroundColor Green
Write-Host ""
Write-Host "1. Otwórz: https://github.com/orgs/Noacodenoobe/projects" -ForegroundColor Cyan
Write-Host "2. Kliknij 'New project'" -ForegroundColor Cyan
Write-Host "3. Wybierz 'Board' (Kanban)" -ForegroundColor Cyan
Write-Host "4. Nazwa: 'BWS Kielce Project Board'" -ForegroundColor Cyan
Write-Host "5. Opis: 'System zarządzania projektem dekoracji ogrodowych'" -ForegroundColor Cyan
Write-Host ""
Write-Host "📋 KONFIGURACJA KOLUMN:" -ForegroundColor Green
Write-Host "=======================" -ForegroundColor Green
Write-Host ""
Write-Host "Dodaj kolumny (od lewej do prawej):" -ForegroundColor Cyan
Write-Host "- 📋 Backlog" -ForegroundColor White
Write-Host "- 🎯 Do zrobienia" -ForegroundColor White
Write-Host "- 🔄 W trakcie" -ForegroundColor White
Write-Host "- ✅ Gotowe" -ForegroundColor White
Write-Host "- 🚫 Zablokowane" -ForegroundColor White
Write-Host ""
Write-Host "📋 AUTOMATYZACJE:" -ForegroundColor Green
Write-Host "=================" -ForegroundColor Green
Write-Host ""
Write-Host "Skonfiguruj automatyzacje:" -ForegroundColor Cyan
Write-Host "- Gdy issue jest otwarte → przenieś do 'Do zrobienia'" -ForegroundColor White
Write-Host "- Gdy issue ma label 'blocked' → przenieś do 'Zablokowane'" -ForegroundColor White
Write-Host "- Gdy issue jest zamknięte → przenieś do 'Gotowe'" -ForegroundColor White
Write-Host ""
Write-Host "📋 FILTRY I WIDOKI:" -ForegroundColor Green
Write-Host "====================" -ForegroundColor Green
Write-Host ""
Write-Host "Utwórz widoki:" -ForegroundColor Cyan
Write-Host "- Wszystkie zadania" -ForegroundColor White
Write-Host "- Zadania krytyczne (label: critical)" -ForegroundColor White
Write-Host "- Zadania na dziś (według daty)" -ForegroundColor White
Write-Host "- Zadania koordynacyjne (label: coordination)" -ForegroundColor White
Write-Host "- Zadania zakupowe (label: purchases)" -ForegroundColor White
Write-Host ""
Write-Host "🔗 LINKI:" -ForegroundColor Green
Write-Host "=========" -ForegroundColor Green
Write-Host ""
Write-Host "Repozytorium: https://github.com/Noacodenoobe/bws-kielce-project" -ForegroundColor Cyan
Write-Host "Zadania: https://github.com/Noacodenoobe/bws-kielce-project/issues" -ForegroundColor Cyan
Write-Host "Projects: https://github.com/orgs/Noacodenoobe/projects" -ForegroundColor Cyan
Write-Host ""
Write-Host "🎯 NASTĘPNE KROKI:" -ForegroundColor Green
Write-Host "==================" -ForegroundColor Green
Write-Host ""
Write-Host "1. Uruchom: gh auth refresh -s project,read:project" -ForegroundColor Yellow
Write-Host "2. Utwórz Project Board ręcznie w przeglądarce" -ForegroundColor Yellow
Write-Host "3. Skonfiguruj kolumny i automatyzacje" -ForegroundColor Yellow
Write-Host "4. Dodaj członków zespołu do repozytorium" -ForegroundColor Yellow
Write-Host "5. Rozpocznij pracę nad zadaniami!" -ForegroundColor Yellow
