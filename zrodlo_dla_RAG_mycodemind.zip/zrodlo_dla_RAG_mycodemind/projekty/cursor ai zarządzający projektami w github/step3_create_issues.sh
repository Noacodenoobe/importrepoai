#!/bin/bash

# KROK 3: Zaimportuj Zadania (Issues)
# ====================================

echo "📝 Tworzenie issues na podstawie danych CSV..."

# Funkcja do mapowania priorytetu
map_priority() {
    case "$1" in
        "Krytyczne") echo "critical" ;;
        "Normalne") echo "normal" ;;
        *) echo "normal" ;;
    esac
}

# Funkcja do mapowania roli
map_role() {
    case "$1" in
        "Koordynacja") echo "coordination" ;;
        "Zakupy") echo "purchases" ;;
        "Logistyka") echo "logistics" ;;
        "Montaż") echo "assembly" ;;
        "Ogrodnictwo") echo "gardening" ;;
        "Koordynacja/Montaż") echo "coordination assembly" ;;
        "Zakupy/Montaż") echo "purchases assembly" ;;
        "Ogrodnictwo/Logistyka") echo "gardening logistics" ;;
        "Logistyka/Koordynacja") echo "logistics coordination" ;;
        "Logistyka/Ogrodnictwo") echo "logistics gardening" ;;
        "Montaż/Ogrodnictwo") echo "assembly gardening" ;;
        *) echo "coordination" ;;
    esac
}

# Funkcja do mapowania etapu na podstawie daty
map_stage() {
    local date="$1"
    case "$date" in
        2025-08-22|2025-08-23) echo "planning" ;;
        2025-08-24|2025-08-25|2025-08-26|2025-08-27|2025-08-28|2025-08-29) echo "preparation" ;;
        2025-08-30|2025-08-31) echo "execution" ;;
        2025-09-01) echo "completion" ;;
        *) echo "planning" ;;
    esac
}

# Główne zadania (bez parent)
echo "🎯 Tworzenie głównych zadań..."

gh issue create --title "Opracowanie listy zadań z estymacjami" \
  --body "**Zadanie nadrzędne:** Główne zadanie planowania
**Notatki:** Rozpisz roboczogodziny i osoby
**Data:** 2025-08-22
**Status:** Do zrobienia" \
  --label "normal" --label "coordination" --label "planning"

gh issue create --title "Przydzielenie zasobów (liczba osób per zadanie)" \
  --body "**Zadanie nadrzędne:** Główne zadanie planowania
**Notatki:** Przeciążenia? Dodaj rezerwę
**Data:** 2025-08-22
**Status:** Do zrobienia" \
  --label "normal" --label "coordination" --label "planning"

gh issue create --title "Zweryfikowanie dostępności i cen paneli na aloweogrodowe.pl" \
  --body "**Zadanie nadrzędne:** Główne zadanie zakupów
**Notatki:** Zweryfikuj model, ilość, cenę
**Data:** 2025-08-23
**Status:** Do zrobienia" \
  --label "critical" --label "purchases" --label "planning"

gh issue create --title "Określenie wymaganą liczbę paneli i złożenie zamówienia z dostawą do piątku" \
  --body "**Zadanie nadrzędne:** Główne zadanie zakupów
**Notatki:** 34 m² + 10–15% zapasu
**Data:** 2025-08-23
**Status:** Do zrobienia" \
  --label "critical" --label "purchases" --label "planning"

gh issue create --title "Potwierdzenie specyfikacji materiałów (klej, tekstylia, dykta)" \
  --body "**Zadanie nadrzędne:** Główne zadanie zakupów
**Notatki:** Klej, tekstylia, dykta – test próbki
**Data:** 2025-08-24
**Status:** Do zrobienia" \
  --label "normal" --label "purchases" --label "assembly" --label "preparation"

gh issue create --title "Zweryfikowanie finalnej liczby kieszeni na rośliny i źródło zakupu" \
  --body "**Zadanie nadrzędne:** Główne zadanie ogrodnictwa
**Notatki:** Układ kieszeni + zapas 2–3 szt.
**Data:** 2025-08-24
**Status:** Do zrobienia" \
  --label "normal" --label "gardening" --label "preparation"

gh issue create --title "Przygotowanie planu transportu roślin (trasa, terminy, osoby odpowiedzialne, pojazd)" \
  --body "**Zadanie nadrzędne:** Główne zadanie logistyki
**Notatki:** Lista roślin, zabezpieczenia, kierowca
**Data:** 2025-08-25
**Status:** Do zrobienia" \
  --label "critical" --label "gardening" --label "logistics" --label "preparation"

gh issue create --title "Zorganizowanie noclegów dla zespołu" \
  --body "**Zadanie nadrzędne:** Główne zadanie logistyki
**Notatki:** Blisko hali, parking dla busa
**Data:** 2025-08-25
**Status:** Do zrobienia" \
  --label "normal" --label "logistics" --label "preparation"

gh issue create --title "Dogadanie ludzi do wykonania paneli i montażu" \
  --body "**Zadanie nadrzędne:** Główne zadanie koordynacji
**Notatki:** Min. 2–3 monterów, potwierdź obecność
**Data:** 2025-08-26
**Status:** Do zrobienia" \
  --label "normal" --label "coordination" --label "assembly" --label "preparation"

gh issue create --title "Zarezerwowanie samochodu" \
  --body "**Zadanie nadrzędne:** Główne zadanie logistyki
**Notatki:** Bus/van, ubezpieczenie
**Data:** 2025-08-26
**Status:** Do zrobienia" \
  --label "normal" --label "logistics" --label "preparation"

gh issue create --title "Przygotowanie szczegółowego harmonogramu przygotowań i montażu wraz z kamieniami milowymi" \
  --body "**Zadanie nadrzędne:** Główne zadanie koordynacji
**Notatki:** Plan 22–31.08 + bufor
**Data:** 2025-08-27
**Status:** Do zrobienia" \
  --label "critical" --label "coordination" --label "preparation"

gh issue create --title "Sprawdzenie stanu zamówionych materiałów i paneli" \
  --body "**Zadanie nadrzędne:** Główne zadanie zakupów
**Notatki:** Ilość, jakość, zdjęcia
**Data:** 2025-08-28
**Status:** Do zrobienia" \
  --label "normal" --label "purchases" --label "preparation"

gh issue create --title "Przygotowanie narzędzi i materiałów do montażu" \
  --body "**Zadanie nadrzędne:** Główne zadanie montażu
**Notatki:** Lista narzędzi, baterie, śruby
**Data:** 2025-08-28
**Status:** Do zrobienia" \
  --label "normal" --label "assembly" --label "preparation"

gh issue create --title "Pakowanie i przygotowanie do wyjazdu" \
  --body "**Zadanie nadrzędne:** Główne zadanie logistyki
**Notatki:** Etykiety, zabezpieczenie roślin
**Data:** 2025-08-29
**Status:** Do zrobienia" \
  --label "normal" --label "logistics" --label "gardening" --label "preparation"

gh issue create --title "Ostateczne potwierdzenie wszystkich szczegółów" \
  --body "**Zadanie nadrzędne:** Główne zadanie koordynacji
**Notatki:** Klient/noclegi/auto – potwierdzenia
**Data:** 2025-08-29
**Status:** Do zrobienia" \
  --label "critical" --label "coordination" --label "preparation"

gh issue create --title "Wyjazd do Kielc" \
  --body "**Zadanie nadrzędne:** Główne zadanie logistyki
**Notatki:** Załadunek, lista obecności
**Data:** 2025-08-30
**Status:** Do zrobienia" \
  --label "critical" --label "logistics" --label "coordination" --label "execution"

gh issue create --title "Rozpoczęcie montażu dekoracji" \
  --body "**Zadanie nadrzędne:** Główne zadanie montażu
**Notatki:** Panele + podkład
**Data:** 2025-08-30
**Status:** Do zrobienia" \
  --label "normal" --label "assembly" --label "gardening" --label "execution"

gh issue create --title "Kontynuacja montażu dekoracji" \
  --body "**Zadanie nadrzędne:** Główne zadanie montażu
**Notatki:** Kieszenie, tekstylia, rośliny
**Data:** 2025-08-31
**Status:** Do zrobienia" \
  --label "normal" --label "assembly" --label "gardening" --label "execution"

gh issue create --title "Sprawdzenie postępów i ewentualne korekty" \
  --body "**Zadanie nadrzędne:** Główne zadanie koordynacji
**Notatki:** Dokumentacja zdjęciowa
**Data:** 2025-08-31
**Status:** Do zrobienia" \
  --label "normal" --label "coordination" --label "execution"

gh issue create --title "Zakończenie montażu dekoracji" \
  --body "**Zadanie nadrzędne:** Główne zadanie montażu
**Notatki:** Ostatnie poprawki i porządek
**Data:** 2025-09-01
**Status:** Do zrobienia" \
  --label "critical" --label "assembly" --label "gardening" --label "completion"

gh issue create --title "Przygotowanie stoisk na targi" \
  --body "**Zadanie nadrzędne:** Główne zadanie montażu
**Notatki:** Oświetlenie, czystość, ekspozycja
**Data:** 2025-09-01
**Status:** Do zrobienia" \
  --label "normal" --label "assembly" --label "gardening" --label "completion"

echo "✅ Główne zadania zostały utworzone!"
echo "🎯 Krok 3 zakończony pomyślnie!"
