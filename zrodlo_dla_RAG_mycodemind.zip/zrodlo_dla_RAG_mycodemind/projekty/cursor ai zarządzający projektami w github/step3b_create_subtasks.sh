#!/bin/bash

# KROK 3B: Zaimportuj Podzadania (Sub-tasks)
# ===========================================

echo "📝 Tworzenie podzadań na podstawie hierarchii..."

# Podzadania dla "Opracowanie listy zadań z estymacjami"
gh issue create --title "Podziel zadania na etapy" \
  --body "**Zadanie nadrzędne:** Opracowanie listy zadań z estymacjami
**Data:** 2025-08-22
**Status:** Do zrobienia" \
  --label "normal" --label "coordination" --label "planning"

gh issue create --title "Oszacuj czas (roboczogodziny)" \
  --body "**Zadanie nadrzędne:** Opracowanie listy zadań z estymacjami
**Data:** 2025-08-22
**Status:** Do zrobienia" \
  --label "normal" --label "coordination" --label "planning"

gh issue create --title "Przypisz osoby" \
  --body "**Zadanie nadrzędne:** Opracowanie listy zadań z estymacjami
**Data:** 2025-08-22
**Status:** Do zrobienia" \
  --label "normal" --label "coordination" --label "planning"

# Podzadania dla "Przydzielenie zasobów"
gh issue create --title "Lista osób i kontaktów" \
  --body "**Zadanie nadrzędne:** Przydzielenie zasobów (liczba osób per zadanie)
**Data:** 2025-08-22
**Status:** Do zrobienia" \
  --label "normal" --label "coordination" --label "planning"

gh issue create --title "Sprawdzenie dostępności" \
  --body "**Zadanie nadrzędne:** Przydzielenie zasobów (liczba osób per zadanie)
**Data:** 2025-08-22
**Status:** Do zrobienia" \
  --label "normal" --label "coordination" --label "planning"

gh issue create --title "Przydział ról" \
  --body "**Zadanie nadrzędne:** Przydzielenie zasobów (liczba osób per zadanie)
**Data:** 2025-08-22
**Status:** Do zrobienia" \
  --label "normal" --label "coordination" --label "planning"

# Podzadania dla "Zweryfikowanie dostępności i cen paneli"
gh issue create --title "Sprawdź aloweogrodowe.pl" \
  --body "**Zadanie nadrzędne:** Zweryfikowanie dostępności i cen paneli na aloweogrodowe.pl
**Data:** 2025-08-23
**Status:** Do zrobienia" \
  --label "critical" --label "purchases" --label "planning"

gh issue create --title "Zrób zrzut ekranu oferty" \
  --body "**Zadanie nadrzędne:** Zweryfikowanie dostępności i cen paneli na aloweogrodowe.pl
**Data:** 2025-08-23
**Status:** Do zrobienia" \
  --label "critical" --label "purchases" --label "planning"

gh issue create --title "Zanotuj czas dostawy" \
  --body "**Zadanie nadrzędne:** Zweryfikowanie dostępności i cen paneli na aloweogrodowe.pl
**Data:** 2025-08-23
**Status:** Do zrobienia" \
  --label "critical" --label "purchases" --label "planning"

# Podzadania dla "Określenie wymaganą liczbę paneli"
gh issue create --title "Policz ilość paneli" \
  --body "**Zadanie nadrzędne:** Określenie wymaganą liczbę paneli i złożenie zamówienia z dostawą do piątku
**Data:** 2025-08-23
**Status:** Do zrobienia" \
  --label "critical" --label "purchases" --label "planning"

gh issue create --title "Złóż zamówienie" \
  --body "**Zadanie nadrzędne:** Określenie wymaganą liczbę paneli i złożenie zamówienia z dostawą do piątku
**Data:** 2025-08-23
**Status:** Do zrobienia" \
  --label "critical" --label "purchases" --label "planning"

gh issue create --title "Potwierdź termin dostawy" \
  --body "**Zadanie nadrzędne:** Określenie wymaganą liczbę paneli i złożenie zamówienia z dostawą do piątku
**Data:** 2025-08-23
**Status:** Do zrobienia" \
  --label "critical" --label "purchases" --label "planning"

# Podzadania dla "Potwierdzenie specyfikacji materiałów"
gh issue create --title "Wybór kleju (parametry)" \
  --body "**Zadanie nadrzędne:** Potwierdzenie specyfikacji materiałów (klej, tekstylia, dykta)
**Data:** 2025-08-24
**Status:** Do zrobienia" \
  --label "normal" --label "purchases" --label "assembly" --label "preparation"

gh issue create --title "Wybór tekstyliów (próbki)" \
  --body "**Zadanie nadrzędne:** Potwierdzenie specyfikacji materiałów (klej, tekstylia, dykta)
**Data:** 2025-08-24
**Status:** Do zrobienia" \
  --label "normal" --label "purchases" --label "assembly" --label "preparation"

gh issue create --title "Określ grubość dykty" \
  --body "**Zadanie nadrzędne:** Potwierdzenie specyfikacji materiałów (klej, tekstylia, dykta)
**Data:** 2025-08-24
**Status:** Do zrobienia" \
  --label "normal" --label "purchases" --label "assembly" --label "preparation"

# Podzadania dla "Zweryfikowanie finalnej liczby kieszeni"
gh issue create --title "Policz rośliny" \
  --body "**Zadanie nadrzędne:** Zweryfikowanie finalnej liczby kieszeni na rośliny i źródło zakupu
**Data:** 2025-08-24
**Status:** Do zrobienia" \
  --label "normal" --label "gardening" --label "preparation"

gh issue create --title "Narysuj układ kieszeni" \
  --body "**Zadanie nadrzędne:** Zweryfikowanie finalnej liczby kieszeni na rośliny i źródło zakupu
**Data:** 2025-08-24
**Status:** Do zrobienia" \
  --label "normal" --label "gardening" --label "preparation"

gh issue create --title "Zamów zapas 2–3 szt." \
  --body "**Zadanie nadrzędne:** Zweryfikowanie finalnej liczby kieszeni na rośliny i źródło zakupu
**Data:** 2025-08-24
**Status:** Do zrobienia" \
  --label "normal" --label "gardening" --label "preparation"

# Podzadania dla "Przygotowanie planu transportu roślin"
gh issue create --title "Lista gatunków i donic" \
  --body "**Zadanie nadrzędne:** Przygotowanie planu transportu roślin (trasa, terminy, osoby odpowiedzialne, pojazd)
**Data:** 2025-08-25
**Status:** Do zrobienia" \
  --label "critical" --label "gardening" --label "logistics" --label "preparation"

gh issue create --title "Materiały ochronne (folie, kartony)" \
  --body "**Zadanie nadrzędne:** Przygotowanie planu transportu roślin (trasa, terminy, osoby odpowiedzialne, pojazd)
**Data:** 2025-08-25
**Status:** Do zrobienia" \
  --label "critical" --label "gardening" --label "logistics" --label "preparation"

gh issue create --title "Plan trasy i godziny" \
  --body "**Zadanie nadrzędne:** Przygotowanie planu transportu roślin (trasa, terminy, osoby odpowiedzialne, pojazd)
**Data:** 2025-08-25
**Status:** Do zrobienia" \
  --label "critical" --label "gardening" --label "logistics" --label "preparation"

# Podzadania dla "Zorganizowanie noclegów"
gh issue create --title "Wybór hotelu" \
  --body "**Zadanie nadrzędne:** Zorganizowanie noclegów dla zespołu
**Data:** 2025-08-25
**Status:** Do zrobienia" \
  --label "normal" --label "logistics" --label "preparation"

gh issue create --title "Rezerwacja pokoi" \
  --body "**Zadanie nadrzędne:** Zorganizowanie noclegów dla zespołu
**Data:** 2025-08-25
**Status:** Do zrobienia" \
  --label "normal" --label "logistics" --label "preparation"

gh issue create --title "Potwierdzenie mailowe" \
  --body "**Zadanie nadrzędne:** Zorganizowanie noclegów dla zespołu
**Data:** 2025-08-25
**Status:** Do zrobienia" \
  --label "normal" --label "logistics" --label "preparation"

# Podzadania dla "Dogadanie ludzi do montażu"
gh issue create --title "Określ liczbę monterów" \
  --body "**Zadanie nadrzędne:** Dogadanie ludzi do wykonania paneli i montażu
**Data:** 2025-08-26
**Status:** Do zrobienia" \
  --label "normal" --label "coordination" --label "assembly" --label "preparation"

gh issue create --title "Ustal stawki i godziny" \
  --body "**Zadanie nadrzędne:** Dogadanie ludzi do wykonania paneli i montażu
**Data:** 2025-08-26
**Status:** Do zrobienia" \
  --label "normal" --label "coordination" --label "assembly" --label "preparation"

gh issue create --title "Potwierdź obecność" \
  --body "**Zadanie nadrzędne:** Dogadanie ludzi do wykonania paneli i montażu
**Data:** 2025-08-26
**Status:** Do zrobienia" \
  --label "normal" --label "coordination" --label "assembly" --label "preparation"

# Podzadania dla "Zarezerwowanie samochodu"
gh issue create --title "Wybór pojazdu" \
  --body "**Zadanie nadrzędne:** Zarezerwowanie samochodu
**Data:** 2025-08-26
**Status:** Do zrobienia" \
  --label "normal" --label "logistics" --label "preparation"

gh issue create --title "Rezerwacja busa/auta" \
  --body "**Zadanie nadrzędne:** Zarezerwowanie samochodu
**Data:** 2025-08-26
**Status:** Do zrobienia" \
  --label "normal" --label "logistics" --label "preparation"

gh issue create --title "Sprawdzenie ubezpieczenia" \
  --body "**Zadanie nadrzędne:** Zarezerwowanie samochodu
**Data:** 2025-08-26
**Status:** Do zrobienia" \
  --label "normal" --label "logistics" --label "preparation"

# Podzadania dla "Przygotowanie harmonogramu"
gh issue create --title "Rozpisz dni i kamienie" \
  --body "**Zadanie nadrzędne:** Przygotowanie szczegółowego harmonogramu przygotowań i montażu wraz z kamieniami milowymi
**Data:** 2025-08-27
**Status:** Do zrobienia" \
  --label "critical" --label "coordination" --label "preparation"

gh issue create --title "Dodaj bufor czasu" \
  --body "**Zadanie nadrzędne:** Przygotowanie szczegółowego harmonogramu przygotowań i montażu wraz z kamieniami milowymi
**Data:** 2025-08-27
**Status:** Do zrobienia" \
  --label "critical" --label "coordination" --label "preparation"

gh issue create --title "Zatwierdź z zespołem" \
  --body "**Zadanie nadrzędne:** Przygotowanie szczegółowego harmonogramu przygotowań i montażu wraz z kamieniami milowymi
**Data:** 2025-08-27
**Status:** Do zrobienia" \
  --label "critical" --label "coordination" --label "preparation"

# Podzadania dla "Sprawdzenie stanu zamówionych materiałów"
gh issue create --title "Sprawdź ilość i jakość" \
  --body "**Zadanie nadrzędne:** Sprawdzenie stanu zamówionych materiałów i paneli
**Data:** 2025-08-28
**Status:** Do zrobienia" \
  --label "normal" --label "purchases" --label "preparation"

gh issue create --title "Zrób zdjęcia" \
  --body "**Zadanie nadrzędne:** Sprawdzenie stanu zamówionych materiałów i paneli
**Data:** 2025-08-28
**Status:** Do zrobienia" \
  --label "normal" --label "purchases" --label "preparation"

gh issue create --title "Zgłoś braki" \
  --body "**Zadanie nadrzędne:** Sprawdzenie stanu zamówionych materiałów i paneli
**Data:** 2025-08-28
**Status:** Do zrobienia" \
  --label "normal" --label "purchases" --label "preparation"

# Podzadania dla "Przygotowanie narzędzi"
gh issue create --title "Lista narzędzi" \
  --body "**Zadanie nadrzędne:** Przygotowanie narzędzi i materiałów do montażu
**Data:** 2025-08-28
**Status:** Do zrobienia" \
  --label "normal" --label "assembly" --label "preparation"

gh issue create --title "Test sprzętu i baterii" \
  --body "**Zadanie nadrzędne:** Przygotowanie narzędzi i materiałów do montażu
**Data:** 2025-08-28
**Status:** Do zrobienia" \
  --label "normal" --label "assembly" --label "preparation"

gh issue create --title "Zakup braków" \
  --body "**Zadanie nadrzędne:** Przygotowanie narzędzi i materiałów do montażu
**Data:** 2025-08-28
**Status:** Do zrobienia" \
  --label "normal" --label "assembly" --label "preparation"

# Podzadania dla "Pakowanie"
gh issue create --title "Pakowanie materiałów" \
  --body "**Zadanie nadrzędne:** Pakowanie i przygotowanie do wyjazdu
**Data:** 2025-08-29
**Status:** Do zrobienia" \
  --label "normal" --label "logistics" --label "gardening" --label "preparation"

gh issue create --title "Etykietowanie kartonów" \
  --body "**Zadanie nadrzędne:** Pakowanie i przygotowanie do wyjazdu
**Data:** 2025-08-29
**Status:** Do zrobienia" \
  --label "normal" --label "logistics" --label "gardening" --label "preparation"

gh issue create --title "Zabezpieczenie roślin" \
  --body "**Zadanie nadrzędne:** Pakowanie i przygotowanie do wyjazdu
**Data:** 2025-08-29
**Status:** Do zrobienia" \
  --label "normal" --label "logistics" --label "gardening" --label "preparation"

# Podzadania dla "Ostateczne potwierdzenie"
gh issue create --title "Telefon do klienta" \
  --body "**Zadanie nadrzędne:** Ostateczne potwierdzenie wszystkich szczegółów
**Data:** 2025-08-29
**Status:** Do zrobienia" \
  --label "critical" --label "coordination" --label "preparation"

gh issue create --title "Potwierdź noclegi i auto" \
  --body "**Zadanie nadrzędne:** Ostateczne potwierdzenie wszystkich szczegółów
**Data:** 2025-08-29
**Status:** Do zrobienia" \
  --label "critical" --label "coordination" --label "preparation"

gh issue create --title "Wyślij PDF z planem" \
  --body "**Zadanie nadrzędne:** Ostateczne potwierdzenie wszystkich szczegółów
**Data:** 2025-08-29
**Status:** Do zrobienia" \
  --label "critical" --label "coordination" --label "preparation"

# Podzadania dla "Wyjazd do Kielc"
gh issue create --title "Spotkanie poranne" \
  --body "**Zadanie nadrzędne:** Wyjazd do Kielc
**Data:** 2025-08-30
**Status:** Do zrobienia" \
  --label "critical" --label "logistics" --label "coordination" --label "execution"

gh issue create --title "Załadunek" \
  --body "**Zadanie nadrzędne:** Wyjazd do Kielc
**Data:** 2025-08-30
**Status:** Do zrobienia" \
  --label "critical" --label "logistics" --label "coordination" --label "execution"

gh issue create --title "Wyjazd wg planu" \
  --body "**Zadanie nadrzędne:** Wyjazd do Kielc
**Data:** 2025-08-30
**Status:** Do zrobienia" \
  --label "critical" --label "logistics" --label "coordination" --label "execution"

# Podzadania dla "Rozpoczęcie montażu"
gh issue create --title "Rozładunek" \
  --body "**Zadanie nadrzędne:** Rozpoczęcie montażu dekoracji
**Data:** 2025-08-30
**Status:** Do zrobienia" \
  --label "normal" --label "assembly" --label "gardening" --label "execution"

gh issue create --title "Montaż paneli" \
  --body "**Zadanie nadrzędne:** Rozpoczęcie montażu dekoracji
**Data:** 2025-08-30
**Status:** Do zrobienia" \
  --label "normal" --label "assembly" --label "gardening" --label "execution"

gh issue create --title "Montaż podkładu" \
  --body "**Zadanie nadrzędne:** Rozpoczęcie montażu dekoracji
**Data:** 2025-08-30
**Status:** Do zrobienia" \
  --label "normal" --label "assembly" --label "gardening" --label "execution"

# Podzadania dla "Kontynuacja montażu"
gh issue create --title "Montaż kieszeni" \
  --body "**Zadanie nadrzędne:** Kontynuacja montażu dekoracji
**Data:** 2025-08-31
**Status:** Do zrobienia" \
  --label "normal" --label "assembly" --label "gardening" --label "execution"

gh issue create --title "Instalacja tekstyliów" \
  --body "**Zadanie nadrzędne:** Kontynuacja montażu dekoracji
**Data:** 2025-08-31
**Status:** Do zrobienia" \
  --label "normal" --label "assembly" --label "gardening" --label "execution"

gh issue create --title "Sadzenie roślin" \
  --body "**Zadanie nadrzędne:** Kontynuacja montażu dekoracji
**Data:** 2025-08-31
**Status:** Do zrobienia" \
  --label "normal" --label "assembly" --label "gardening" --label "execution"

# Podzadania dla "Sprawdzenie postępów"
gh issue create --title "Przegląd jakości" \
  --body "**Zadanie nadrzędne:** Sprawdzenie postępów i ewentualne korekty
**Data:** 2025-08-31
**Status:** Do zrobienia" \
  --label "normal" --label "coordination" --label "execution"

gh issue create --title "Korekty" \
  --body "**Zadanie nadrzędne:** Sprawdzenie postępów i ewentualne korekty
**Data:** 2025-08-31
**Status:** Do zrobienia" \
  --label "normal" --label "coordination" --label "execution"

gh issue create --title "Zdjęcia dokumentacyjne" \
  --body "**Zadanie nadrzędne:** Sprawdzenie postępów i ewentualne korekty
**Data:** 2025-08-31
**Status:** Do zrobienia" \
  --label "normal" --label "coordination" --label "execution"

# Podzadania dla "Zakończenie montażu"
gh issue create --title "Ostatnie poprawki" \
  --body "**Zadanie nadrzędne:** Zakończenie montażu dekoracji
**Data:** 2025-09-01
**Status:** Do zrobienia" \
  --label "critical" --label "assembly" --label "gardening" --label "completion"

gh issue create --title "Sprzątanie" \
  --body "**Zadanie nadrzędne:** Zakończenie montażu dekoracji
**Data:** 2025-09-01
**Status:** Do zrobienia" \
  --label "critical" --label "assembly" --label "gardening" --label "completion"

gh issue create --title "Przegląd końcowy" \
  --body "**Zadanie nadrzędne:** Zakończenie montażu dekoracji
**Data:** 2025-09-01
**Status:** Do zrobienia" \
  --label "critical" --label "assembly" --label "gardening" --label "completion"

# Podzadania dla "Przygotowanie stoisk"
gh issue create --title "Ustaw ekspozycje" \
  --body "**Zadanie nadrzędne:** Przygotowanie stoisk na targi
**Data:** 2025-09-01
**Status:** Do zrobienia" \
  --label "normal" --label "assembly" --label "gardening" --label "completion"

gh issue create --title "Sprawdź oświetlenie" \
  --body "**Zadanie nadrzędne:** Przygotowanie stoisk na targi
**Data:** 2025-09-01
**Status:** Do zrobienia" \
  --label "normal" --label "assembly" --label "gardening" --label "completion"

gh issue create --title "Finalne zdjęcia" \
  --body "**Zadanie nadrzędne:** Przygotowanie stoisk na targi
**Data:** 2025-09-01
**Status:** Do zrobienia" \
  --label "normal" --label "assembly" --label "gardening" --label "completion"

echo "✅ Wszystkie podzadania zostały utworzone!"
echo "🎯 Krok 3B zakończony pomyślnie!"
