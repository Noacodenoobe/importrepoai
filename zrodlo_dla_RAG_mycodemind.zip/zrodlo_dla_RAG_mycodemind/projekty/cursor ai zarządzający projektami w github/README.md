# 🌿 BWS Kielce Project

System zarządzania projektem dekoracji ogrodowych dla BWS Kielce.

## 📋 Szybki Start

1. **Otwórz [Project Board](https://github.com/users/Noacodenoobe/projects/10)**
2. **Sprawdź zadania krytyczne** (etykieta `critical`)
3. **Aktualizuj status zadań** w kolumnach Kanban
4. **Użyj szablonów** przy tworzeniu nowych zadań

## 👥 Rola w Zespole

- **🔵 Koordynator**: Zarządza całym projektem, przypisuje zadania, monitoruje postępy
- **🟣 Zakupy**: Materiały, dostawcy, zamówienia, budżet
- **🟡 Logistyka**: Transport, noclegi, trasy, harmonogram
- **🔴 Montaż**: Prace techniczne, narzędzia, instalacja
- **🟢 Ogrodnictwo**: Rośliny, aranżacja, podłoże, pielęgnacja

## 📊 Struktura projektu

### Zadania (Issues)
- **Główne zadania**: 22 zadań nadrzędnych
- **Podzadania**: 63 szczegółowych kroków
- **Łącznie**: 85 zadań w systemie
- **Etykiety**: Priorytet, rola, etap, status

### Etykiety (Labels)

#### Priorytet
- `critical` - Zadania krytyczne
- `high` - Zadania wysokiego priorytetu  
- `normal` - Zadania normalnego priorytetu
- `low` - Zadania niskiego priorytetu

#### Rola
- `coordination` - Zadania koordynacyjne
- `purchases` - Zadania zakupowe
- `logistics` - Zadania logistyczne
- `assembly` - Zadania montażowe
- `gardening` - Zadania ogrodnicze

#### Etap
- `planning` - Etap planowania (22-23.08)
- `preparation` - Etap przygotowań (24-29.08)
- `execution` - Etap wykonania (30-31.08)
- `completion` - Etap zakończenia (01.09)

#### Status
- `blocked` - Zadanie zablokowane
- `waiting` - Oczekujące na akcję
- `ready` - Gotowe do wykonania

## 🎯 Harmonogram

- **22-23.08.2025**: Planowanie
- **24-29.08.2025**: Przygotowania
- **30-31.08.2025**: Wykonanie
- **01.09.2025**: Zakończenie

## 📋 Codzienna checklista

1. Sprawdź zadania z etykietą `critical`
2. Przejrzyj zadania na dziś (według daty)
3. Zaktualizuj status zadań w toku
4. Sprawdź blokady i zależności

## 🤖 Automatyzacje

### GitHub Actions
- **Automatyczne etykietowanie** - Issues są automatycznie etykietowane na podstawie treści
- **Codzienne podsumowania** - Raporty o postępach projektu

### Powiadomienia
- **Email** - O nowych zadaniach i zmianach statusu
- **GitHub** - Powiadomienia w czasie rzeczywistym

## 🔗 Przydatne linki

- **Project Board**: https://github.com/users/Noacodenoobe/projects/10
- **Wszystkie zadania**: https://github.com/Noacodenoobe/bws-kielce-project/issues
- **Etykiety**: https://github.com/Noacodenoobe/bws-kielce-project/labels
- **Szablony**: https://github.com/Noacodenoobe/bws-kielce-project/issues/new/choose

## 📞 Kontakt

- **Koordynacja**: koordynacja@projekt.pl
- **Zakupy**: zakupy@projekt.pl
- **Logistyka**: logistyka@projekt.pl
- **Montaż**: montaz@projekt.pl
- **Ogrodnictwo**: ogrodnictwo@projekt.pl

## 🚀 Jak używać

### Tworzenie zadania
1. Kliknij **"New issue"**
2. Wybierz odpowiedni **szablon**:
   - 🚨 Zadanie Krytyczne
   - 🛒 Zadanie Zakupowe
   - 🚚 Zadanie Logistyczne
   - 🔧 Zadanie Montażowe
   - 🌿 Zadanie Ogrodnicze
3. Wypełnij dane w szablonie
4. Przypisz odpowiednie **etykiety**

### Aktualizacja statusu
1. Otwórz zadanie w **Project Board**
2. Przeciągnij do odpowiedniej kolumny:
   - 📋 **Backlog** - Nowe zadania
   - 🎯 **Do zrobienia** - Gotowe do rozpoczęcia
   - 🔄 **W trakcie** - W realizacji
   - ✅ **Gotowe** - Ukończone
   - 🚫 **Zablokowane** - Z problemami
3. Dodaj komentarz z postępem

### Filtrowanie zadań
- Użyj **widoków** w Project Board
- Filtruj po **etykietach** (priorytet, rola, etap)
- Sortuj po **datach** lub **przypisaniach**

## 📈 Postęp projektu

- ✅ Repozytorium utworzone
- ✅ Etykiety skonfigurowane (15 etykiet)
- ✅ Główne zadania utworzone (22 zadania)
- ✅ Podzadania utworzone (63 zadania)
- ✅ Project Board skonfigurowany
- ✅ Szablony issues utworzone (5 szablonów)
- ✅ GitHub Actions skonfigurowane
- ✅ Automatyzacje włączone
- 🎉 **Projekt gotowy do użycia!**

## 🚀 Następne kroki
1. **Dodaj członków zespołu** do repozytorium
2. **Skonfiguruj kolumny** w Project Board
3. **Rozpocznij pracę** nad zadaniami
4. **Monitoruj postępy** codziennie
