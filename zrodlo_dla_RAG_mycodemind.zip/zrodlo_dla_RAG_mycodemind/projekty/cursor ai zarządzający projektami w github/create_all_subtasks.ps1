# Skrypt do utworzenia wszystkich podzadań z CSV
Write-Host "🎯 Tworzenie podzadań z CSV..." -ForegroundColor Cyan

# Przejdź do katalogu repozytorium
Set-Location "bws-kielce-project"
Write-Host "📁 Przejście do katalogu repozytorium..." -ForegroundColor Yellow

# Funkcja do mapowania priorytetów
function Get-PriorityLabel {
    param($priority)
    switch ($priority) {
        "Krytyczne" { return "critical" }
        "Normalne" { return "normal" }
        "Wysokie" { return "high" }
        "Niskie" { return "low" }
        default { return "normal" }
    }
}

# Funkcja do mapowania ról
function Get-RoleLabel {
    param($role)
    switch ($role) {
        "Koordynacja" { return "coordination" }
        "Zakupy" { return "purchases" }
        "Logistyka" { return "logistics" }
        "Montaż" { return "assembly" }
        "Ogrodnictwo" { return "gardening" }
        "Zakupy/Montaż" { return "purchases", "assembly" }
        "Ogrodnictwo/Logistyka" { return "gardening", "logistics" }
        "Koordynacja/Montaż" { return "coordination", "assembly" }
        "Logistyka/Ogrodnictwo" { return "logistics", "gardening" }
        "Montaż/Ogrodnictwo" { return "assembly", "gardening" }
        "Logistyka/Koordynacja" { return "logistics", "coordination" }
        default { return "coordination" }
    }
}

# Funkcja do mapowania etapów
function Get-PhaseLabel {
    param($date)
    $dateObj = [DateTime]::ParseExact($date, "yyyy-MM-dd", $null)
    switch ($dateObj.Day) {
        { $_ -in 22, 23 } { return "planning" }
        { $_ -in 24..29 } { return "preparation" }
        { $_ -in 30, 31 } { return "execution" }
        1 { return "completion" }
        default { return "preparation" }
    }
}

# Wczytaj CSV
$csvPath = "../dokumenty_wstepne/BWS_Kielce___Tasks_Master__z_hierarchi__.csv"
$tasks = Import-Csv $csvPath

# Filtruj tylko podzadania (z Parent)
$subtasks = $tasks | Where-Object { $_.Parent -ne "—" -and $_.Parent -ne "" }

Write-Host "📊 Znaleziono $($subtasks.Count) podzadań do utworzenia" -ForegroundColor Yellow

# Utwórz podzadania
$counter = 0
foreach ($task in $subtasks) {
    $counter++
    Write-Host "🔄 Tworzenie zadania $counter/$($subtasks.Count): $($task.Task)" -ForegroundColor Cyan
    
    # Przygotuj etykiety
    $priorityLabel = Get-PriorityLabel $task.Priority
    $roleLabels = Get-RoleLabel $task.Role
    $phaseLabel = Get-PhaseLabel $task.Date
    
    # Przygotuj body
    $body = "**Zadanie nadrzędne:** $($task.Parent)`n"
    if ($task.Notes -and $task.Notes -ne "") {
        $body += "**Notatki:** $($task.Notes)`n"
    }
    $body += "**Data:** $($task.Date)`n"
    $body += "**Status:** $($task.Status)"
    
    # Przygotuj komendę gh
    $ghCommand = "gh issue create --title `"$($task.Task)`" --body `"$body`" --label `"$priorityLabel`""
    
    # Dodaj etykiety ról
    if ($roleLabels -is [array]) {
        foreach ($role in $roleLabels) {
            $ghCommand += " --label `"$role`""
        }
    } else {
        $ghCommand += " --label `"$roleLabels`""
    }
    
    # Dodaj etykietę etapu
    $ghCommand += " --label `"$phaseLabel`""
    
    # Wykonaj komendę
    try {
        Invoke-Expression $ghCommand
        Write-Host "✅ Utworzono: $($task.Task)" -ForegroundColor Green
    } catch {
        Write-Host "❌ Błąd przy tworzeniu: $($task.Task)" -ForegroundColor Red
        Write-Host "Komenda: $ghCommand" -ForegroundColor Gray
    }
    
    # Krótka przerwa między zadaniami
    Start-Sleep -Milliseconds 500
}

Write-Host "🎉 Zakończono tworzenie podzadań!" -ForegroundColor Green
Write-Host "📊 Utworzono $counter podzadań" -ForegroundColor Cyan
