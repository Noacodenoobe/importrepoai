#!/bin/bash

# KROK 1: Stwórz Repozytorium i Projekt
# ======================================

echo "🌿 Tworzenie repozytorium BWS Kielce Project..."

# 1. Utwórz nowe, prywatne repozytorium
gh repo create bws-kielce-project \
  --private \
  --description "BWS Kielce Project - System zarządzania projektem dekoracji ogrodowych" \
  --homepage "https://github.com/$(gh api user --jq .login)/bws-kielce-project"

echo "✅ Repozytorium utworzone!"

# 2. Utwórz nowy projekt i połącz z repozytorium
gh project create "BWS Kielce Project" \
  --owner $(gh api user --jq .login) \
  --format json \
  --jq '.number' > project_number.txt

PROJECT_NUMBER=$(cat project_number.txt)

# Dodaj repozytorium do projektu
gh project item-add $PROJECT_NUMBER \
  --owner $(gh api user --jq .login) \
  --repo $(gh api user --jq .login)/bws-kielce-project

echo "✅ Projekt utworzony i połączony z repozytorium!"
echo "📊 Numer projektu: $PROJECT_NUMBER"

# Wyczyść plik tymczasowy
rm project_number.txt

echo "🎯 Krok 1 zakończony pomyślnie!"
