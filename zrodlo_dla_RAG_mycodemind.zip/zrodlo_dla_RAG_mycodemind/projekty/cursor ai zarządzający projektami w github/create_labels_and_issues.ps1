# Uproszczony skrypt do utworzenia etykiet i zadań
Write-Host "🏷️ Tworzenie etykiet..." -ForegroundColor Cyan

# Priorytet - Labels
gh label create "high" --color "#FF6B35" --description "Zadania wysokiego priorytetu"
gh label create "normal" --color "#4ECDC4" --description "Zadania normalnego priorytetu"
gh label create "low" --color "#95A5A6" --description "Zadania niskiego priorytetu"

# Rola - Labels
gh label create "coordination" --color "#3498DB" --description "Zadania koordynacyjne"
gh label create "purchases" --color "#E74C3C" --description "Zadania zakupowe"
gh label create "logistics" --color "#F39C12" --description "Zadania logistyczne"
gh label create "assembly" --color "#27AE60" --description "Zadania montażowe"
gh label create "gardening" --color "#8E44AD" --description "Zadania ogrodnicze"

# Etap - Labels
gh label create "planning" --color "#1ABC9C" --description "Etap planowania"
gh label create "preparation" --color "#F1C40F" --description "Etap przygotowań"
gh label create "execution" --color "#E67E22" --description "Etap wykonania"
gh label create "completion" --color "#9B59B6" --description "Etap zakończenia"

# Status - Labels
gh label create "blocked" --color "#E74C3C" --description "Zadanie zablokowane"
gh label create "waiting" --color "#F39C12" --description "Oczekujące na akcję"
gh label create "ready" --color "#27AE60" --description "Gotowe do wykonania"

Write-Host "✅ Etykiety utworzone!" -ForegroundColor Green

Write-Host "🎯 Tworzenie głównych zadań..." -ForegroundColor Cyan

# Główne zadania
gh issue create --title "Opracowanie listy zadań z estymacjami" --body "**Notatki:** Rozpisz roboczogodziny i osoby`n**Data:** 2025-08-22" --label "normal" --label "coordination" --label "planning"

gh issue create --title "Przydzielenie zasobów" --body "**Notatki:** Przeciążenia? Dodaj rezerwę`n**Data:** 2025-08-22" --label "normal" --label "coordination" --label "planning"

gh issue create --title "Zweryfikowanie dostępności i cen paneli" --body "**Notatki:** Zweryfikuj model, ilość, cenę`n**Data:** 2025-08-23" --label "critical" --label "purchases" --label "planning"

gh issue create --title "Zamówienie paneli" --body "**Notatki:** 34 m² + 10–15% zapasu`n**Data:** 2025-08-23" --label "critical" --label "purchases" --label "planning"

gh issue create --title "Specyfikacja materiałów" --body "**Notatki:** Klej, tekstylia, dykta – test próbki`n**Data:** 2025-08-24" --label "normal" --label "purchases" --label "assembly" --label "preparation"

gh issue create --title "Kieszenie na rośliny" --body "**Notatki:** Układ kieszeni + zapas 2–3 szt.`n**Data:** 2025-08-24" --label "normal" --label "gardening" --label "preparation"

gh issue create --title "Transport roślin" --body "**Notatki:** Lista roślin, zabezpieczenia, kierowca`n**Data:** 2025-08-25" --label "critical" --label "gardening" --label "logistics" --label "preparation"

gh issue create --title "Noclegi dla zespołu" --body "**Notatki:** Blisko hali, parking dla busa`n**Data:** 2025-08-25" --label "normal" --label "logistics" --label "preparation"

gh issue create --title "Ludzie do montażu" --body "**Notatki:** Min. 2–3 monterów, potwierdź obecność`n**Data:** 2025-08-26" --label "normal" --label "coordination" --label "assembly" --label "preparation"

gh issue create --title "Rezerwacja samochodu" --body "**Notatki:** Bus/van, ubezpieczenie`n**Data:** 2025-08-26" --label "normal" --label "logistics" --label "preparation"

gh issue create --title "Harmonogram projektu" --body "**Notatki:** Plan 22–31.08 + bufor`n**Data:** 2025-08-27" --label "critical" --label "coordination" --label "preparation"

gh issue create --title "Kontrola dostaw" --body "**Notatki:** Ilość, jakość, zdjęcia`n**Data:** 2025-08-28" --label "normal" --label "purchases" --label "preparation"

gh issue create --title "Przygotowanie narzędzi" --body "**Notatki:** Lista narzędzi, baterie, śruby`n**Data:** 2025-08-28" --label "normal" --label "assembly" --label "preparation"

gh issue create --title "Pakowanie do wyjazdu" --body "**Notatki:** Etykiety, zabezpieczenie roślin`n**Data:** 2025-08-29" --label "normal" --label "logistics" --label "gardening" --label "preparation"

gh issue create --title "Ostateczne potwierdzenie" --body "**Notatki:** Klient/noclegi/auto – potwierdzenia`n**Data:** 2025-08-29" --label "critical" --label "coordination" --label "preparation"

gh issue create --title "Wyjazd do Kielc" --body "**Notatki:** Załadunek, lista obecności`n**Data:** 2025-08-30" --label "critical" --label "logistics" --label "coordination" --label "execution"

gh issue create --title "Rozpoczęcie montażu" --body "**Notatki:** Panele + podkład`n**Data:** 2025-08-30" --label "normal" --label "assembly" --label "gardening" --label "execution"

gh issue create --title "Kontynuacja montażu" --body "**Notatki:** Kieszenie, tekstylia, rośliny`n**Data:** 2025-08-31" --label "normal" --label "assembly" --label "gardening" --label "execution"

gh issue create --title "Sprawdzenie postępów" --body "**Notatki:** Dokumentacja zdjęciowa`n**Data:** 2025-08-31" --label "normal" --label "coordination" --label "execution"

gh issue create --title "Zakończenie montażu" --body "**Notatki:** Ostatnie poprawki i porządek`n**Data:** 2025-09-01" --label "critical" --label "assembly" --label "gardening" --label "completion"

gh issue create --title "Przygotowanie stoisk" --body "**Notatki:** Oświetlenie, czystość, ekspozycja`n**Data:** 2025-09-01" --label "normal" --label "assembly" --label "gardening" --label "completion"

Write-Host "✅ Zadania utworzone!" -ForegroundColor Green

# Utwórz README
$readmeContent = @"
# 🌿 BWS Kielce Project

System zarządzania projektem dekoracji ogrodowych dla BWS Kielce.

## 📊 Struktura projektu

### Zadania (Issues)
- **Główne zadania**: 21 zadań nadrzędnych
- **Etykiety**: Priorytet, rola, etap, status

### Etykiety (Labels)

#### Priorytet
- `critical` - Zadania krytyczne
- `high` - Zadania wysokiego priorytetu  
- `normal` - Zadania normalnego priorytetu
- `low` - Zadania niskiego priorytetu

#### Rola
- `coordination` - Zadania koordynacyjne
- `purchases` - Zadania zakupowe
- `logistics` - Zadania logistyczne
- `assembly` - Zadania montażowe
- `gardening` - Zadania ogrodnicze

#### Etap
- `planning` - Etap planowania (22-23.08)
- `preparation` - Etap przygotowań (24-29.08)
- `execution` - Etap wykonania (30-31.08)
- `completion` - Etap zakończenia (01.09)

## 🎯 Harmonogram

- **22-23.08.2025**: Planowanie
- **24-29.08.2025**: Przygotowania
- **30-31.08.2025**: Wykonanie
- **01.09.2025**: Zakończenie

## 📞 Kontakt

- **Koordynacja**: koordynacja@projekt.pl
- **Zakupy**: zakupy@projekt.pl
- **Logistyka**: logistyka@projekt.pl
- **Montaż**: montaz@projekt.pl
- **Ogrodnictwo**: ogrodnictwo@projekt.pl
"@

$readmeContent | Out-File -FilePath "README.md" -Encoding UTF8

Write-Host "✅ README.md utworzony!" -ForegroundColor Green
Write-Host "🎉 Projekt gotowy!" -ForegroundColor Green
