# Skrypt do dodawania członków zespołu
Write-Host "👥 Dodawanie członków zespołu..." -ForegroundColor Cyan

Write-Host "📋 INSTRUKCJE DODAWANIA CZŁONKÓW ZESPOŁU:" -ForegroundColor Green
Write-Host "===========================================" -ForegroundColor Green
Write-Host ""

# Lista proponowanych członków zespołu
$teamMembers = @(
    @{
        Role = "Koordynator projektu"
        Username = "koordynator"
        Email = "koordynacja@projekt.pl"
        Permissions = "Write"
    },
    @{
        Role = "Zakupy"
        Username = "zakupy"
        Email = "zakupy@projekt.pl"
        Permissions = "Write"
    },
    @{
        Role = "Logistyka"
        Username = "logistyka"
        Email = "logistyka@projekt.pl"
        Permissions = "Write"
    },
    @{
        Role = "Montaż"
        Username = "montaz"
        Email = "montaz@projekt.pl"
        Permissions = "Write"
    },
    @{
        Role = "Ogrodnictwo"
        Username = "ogrodnictwo"
        Email = "ogrodnictwo@projekt.pl"
        Permissions = "Write"
    }
)

Write-Host "👥 PROPONOWANI CZŁONKOWIE ZESPOŁU:" -ForegroundColor Yellow
Write-Host "==================================" -ForegroundColor Yellow
foreach ($member in $teamMembers) {
    Write-Host "• $($member.Role): $($member.Username) ($($member.Email))" -ForegroundColor White
}

Write-Host ""
Write-Host "🔗 LINKI DO ZARZĄDZANIA ZESPOŁEM:" -ForegroundColor Green
Write-Host "==================================" -ForegroundColor Green
Write-Host ""
Write-Host "Repozytorium: https://github.com/Noacodenoobe/bws-kielce-project" -ForegroundColor Cyan
Write-Host "Settings → Collaborators: https://github.com/Noacodenoobe/bws-kielce-project/settings/access" -ForegroundColor Cyan
Write-Host ""

Write-Host "📋 KOMENDY DO DODAWANIA CZŁONKÓW:" -ForegroundColor Green
Write-Host "==================================" -ForegroundColor Green
Write-Host ""

foreach ($member in $teamMembers) {
    Write-Host "# Dodaj $($member.Role)" -ForegroundColor Yellow
    Write-Host "gh repo add-collaborator Noacodenoobe/bws-kielce-project $($member.Username) --permission $($member.Permissions)" -ForegroundColor Gray
    Write-Host ""
}

Write-Host "📋 ALTERNATYWNE SPOSOBY:" -ForegroundColor Green
Write-Host "=======================" -ForegroundColor Green
Write-Host ""
Write-Host "1. Przez przeglądarkę:" -ForegroundColor Cyan
Write-Host "   - Otwórz: https://github.com/Noacodenoobe/bws-kielce-project/settings/access" -ForegroundColor White
Write-Host "   - Kliknij 'Add people'" -ForegroundColor White
Write-Host "   - Wpisz username lub email" -ForegroundColor White
Write-Host "   - Wybierz uprawnienia (Write/Read)" -ForegroundColor White
Write-Host ""
Write-Host "2. Przez GitHub CLI:" -ForegroundColor Cyan
Write-Host "   - Użyj komend powyżej" -ForegroundColor White
Write-Host "   - Lub: gh repo add-collaborator <username> --permission <level>" -ForegroundColor White
Write-Host ""

Write-Host "🎯 UPRAWNIENIA:" -ForegroundColor Green
Write-Host "===============" -ForegroundColor Green
Write-Host ""
Write-Host "• Read: Może przeglądać i komentować" -ForegroundColor White
Write-Host "• Write: Może edytować, tworzyć issues, PR" -ForegroundColor White
Write-Host "• Admin: Pełne uprawnienia (nie zalecane)" -ForegroundColor White
Write-Host ""

Write-Host "📞 KONTAKT Z CZŁONKAMI ZESPOŁU:" -ForegroundColor Green
Write-Host "===============================" -ForegroundColor Green
Write-Host ""
Write-Host "Po dodaniu członków, wyślij im:" -ForegroundColor Cyan
Write-Host "• Link do repozytorium" -ForegroundColor White
Write-Host "• Link do Project Board" -ForegroundColor White
Write-Host "• Instrukcje użytkowania" -ForegroundColor White
Write-Host "• Harmonogram projektu" -ForegroundColor White
