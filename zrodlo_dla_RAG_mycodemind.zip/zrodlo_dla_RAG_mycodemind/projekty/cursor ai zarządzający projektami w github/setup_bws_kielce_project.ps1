# 🌿 BWS Kielce Project - Automatyczna konfiguracja (PowerShell)
# ================================================================

Write-Host "🚀 Rozpoczynam automatyczną konfigurację projektu BWS Kielce..." -ForegroundColor Green
Write-Host "================================================================" -ForegroundColor Green

# Sprawdź czy GitHub CLI jest zainstalowany
try {
    $ghVersion = gh --version
    Write-Host "✅ GitHub CLI jest zainstalowany" -ForegroundColor Green
} catch {
    Write-Host "❌ GitHub CLI nie jest zainstalowany. Zainstaluj go z: https://cli.github.com/" -ForegroundColor Red
    exit 1
}

# Sprawdź czy użytkownik jest zalogowany
try {
    $authStatus = gh auth status
    Write-Host "✅ Jesteś zalogowany do GitHub CLI" -ForegroundColor Green
} catch {
    Write-Host "❌ Nie jesteś zalogowany do GitHub CLI. Uruchom: gh auth login" -ForegroundColor Red
    exit 1
}

# KROK 1: Utwórz repozytorium i projekt
Write-Host ""
Write-Host "📋 KROK 1: Tworzenie repozytorium i projektu..." -ForegroundColor Yellow
Write-Host "================================================" -ForegroundColor Yellow

Write-Host "🌿 Tworzenie repozytorium BWS Kielce Project..." -ForegroundColor Cyan

# 1. Utwórz nowe, prywatne repozytorium
try {
    gh repo create bws-kielce-project --private --description "BWS Kielce Project - System zarządzania projektem dekoracji ogrodowych"
    Write-Host "✅ Repozytorium utworzone!" -ForegroundColor Green
} catch {
    Write-Host "❌ Błąd podczas tworzenia repozytorium" -ForegroundColor Red
    exit 1
}

# 2. Utwórz nowy projekt i połącz z repozytorium
try {
    $projectOutput = gh project create "BWS Kielce Project" --format json
    $projectData = $projectOutput | ConvertFrom-Json
    $projectNumber = $projectData.number
    
    # Dodaj repozytorium do projektu
    $username = (gh api user --jq .login).Trim('"')
    gh project item-add $projectNumber --owner $username --repo $username/bws-kielce-project
    
    Write-Host "✅ Projekt utworzony i połączony z repozytorium!" -ForegroundColor Green
    Write-Host "📊 Numer projektu: $projectNumber" -ForegroundColor Cyan
} catch {
    Write-Host "❌ Błąd podczas tworzenia projektu" -ForegroundColor Red
    exit 1
}

# Przejdź do katalogu repozytorium
Set-Location bws-kielce-project

# KROK 2: Utwórz etykiety
Write-Host ""
Write-Host "📋 KROK 2: Tworzenie etykiet..." -ForegroundColor Yellow
Write-Host "================================" -ForegroundColor Yellow

Write-Host "🏷️ Tworzenie etykiet dla projektu BWS Kielce..." -ForegroundColor Cyan

# Priorytet - Labels
Write-Host "📊 Tworzenie etykiet priorytetu..." -ForegroundColor Cyan
gh label create "critical" --color "#FF0000" --description "Zadania krytyczne - najwyższy priorytet"
gh label create "high" --color "#FF6B35" --description "Zadania wysokiego priorytetu"
gh label create "normal" --color "#4ECDC4" --description "Zadania normalnego priorytetu"
gh label create "low" --color "#95A5A6" --description "Zadania niskiego priorytetu"

# Rola - Labels
Write-Host "👥 Tworzenie etykiet ról..." -ForegroundColor Cyan
gh label create "coordination" --color "#3498DB" --description "Zadania koordynacyjne"
gh label create "purchases" --color "#E74C3C" --description "Zadania zakupowe"
gh label create "logistics" --color "#F39C12" --description "Zadania logistyczne"
gh label create "assembly" --color "#27AE60" --description "Zadania montażowe"
gh label create "gardening" --color "#8E44AD" --description "Zadania ogrodnicze"

# Etap - Labels
Write-Host "📋 Tworzenie etykiet etapów..." -ForegroundColor Cyan
gh label create "planning" --color "#1ABC9C" --description "Etap planowania"
gh label create "preparation" --color "#F1C40F" --description "Etap przygotowań"
gh label create "execution" --color "#E67E22" --description "Etap wykonania"
gh label create "completion" --color "#9B59B6" --description "Etap zakończenia"

# Status - Labels
Write-Host "🔄 Tworzenie etykiet statusu..." -ForegroundColor Cyan
gh label create "blocked" --color "#E74C3C" --description "Zadanie zablokowane"
gh label create "waiting" --color "#F39C12" --description "Oczekujące na akcję"
gh label create "ready" --color "#27AE60" --description "Gotowe do wykonania"

# Dodatkowe etykiety specyficzne dla projektu
Write-Host "🎯 Tworzenie dodatkowych etykiet..." -ForegroundColor Cyan
gh label create "milestone" --color "#34495E" --description "Kamień milowy projektu"
gh label create "documentation" --color "#16A085" --description "Dokumentacja"
gh label create "quality-check" --color "#D35400" --description "Kontrola jakości"
gh label create "client-communication" --color "#8E44AD" --description "Komunikacja z klientem"

Write-Host "✅ Wszystkie etykiety zostały utworzone!" -ForegroundColor Green

# KROK 3: Utwórz główne zadania
Write-Host ""
Write-Host "📋 KROK 3: Tworzenie głównych zadań..." -ForegroundColor Yellow
Write-Host "======================================" -ForegroundColor Yellow

Write-Host "🎯 Tworzenie głównych zadań..." -ForegroundColor Cyan

# Główne zadania (bez parent)
gh issue create --title "Opracowanie listy zadań z estymacjami" --body "**Zadanie nadrzędne:** Główne zadanie planowania`n**Notatki:** Rozpisz roboczogodziny i osoby`n**Data:** 2025-08-22`n**Status:** Do zrobienia" --label "normal" --label "coordination" --label "planning"

gh issue create --title "Przydzielenie zasobów (liczba osób per zadanie)" --body "**Zadanie nadrzędne:** Główne zadanie planowania`n**Notatki:** Przeciążenia? Dodaj rezerwę`n**Data:** 2025-08-22`n**Status:** Do zrobienia" --label "normal" --label "coordination" --label "planning"

gh issue create --title "Zweryfikowanie dostępności i cen paneli na aloweogrodowe.pl" --body "**Zadanie nadrzędne:** Główne zadanie zakupów`n**Notatki:** Zweryfikuj model, ilość, cenę`n**Data:** 2025-08-23`n**Status:** Do zrobienia" --label "critical" --label "purchases" --label "planning"

gh issue create --title "Określenie wymaganą liczbę paneli i złożenie zamówienia z dostawą do piątku" --body "**Zadanie nadrzędne:** Główne zadanie zakupów`n**Notatki:** 34 m² + 10–15% zapasu`n**Data:** 2025-08-23`n**Status:** Do zrobienia" --label "critical" --label "purchases" --label "planning"

gh issue create --title "Potwierdzenie specyfikacji materiałów (klej, tekstylia, dykta)" --body "**Zadanie nadrzędne:** Główne zadanie zakupów`n**Notatki:** Klej, tekstylia, dykta – test próbki`n**Data:** 2025-08-24`n**Status:** Do zrobienia" --label "normal" --label "purchases" --label "assembly" --label "preparation"

gh issue create --title "Zweryfikowanie finalnej liczby kieszeni na rośliny i źródło zakupu" --body "**Zadanie nadrzędne:** Główne zadanie ogrodnictwa`n**Notatki:** Układ kieszeni + zapas 2–3 szt.`n**Data:** 2025-08-24`n**Status:** Do zrobienia" --label "normal" --label "gardening" --label "preparation"

gh issue create --title "Przygotowanie planu transportu roślin (trasa, terminy, osoby odpowiedzialne, pojazd)" --body "**Zadanie nadrzędne:** Główne zadanie logistyki`n**Notatki:** Lista roślin, zabezpieczenia, kierowca`n**Data:** 2025-08-25`n**Status:** Do zrobienia" --label "critical" --label "gardening" --label "logistics" --label "preparation"

gh issue create --title "Zorganizowanie noclegów dla zespołu" --body "**Zadanie nadrzędne:** Główne zadanie logistyki`n**Notatki:** Blisko hali, parking dla busa`n**Data:** 2025-08-25`n**Status:** Do zrobienia" --label "normal" --label "logistics" --label "preparation"

gh issue create --title "Dogadanie ludzi do wykonania paneli i montażu" --body "**Zadanie nadrzędne:** Główne zadanie koordynacji`n**Notatki:** Min. 2–3 monterów, potwierdź obecność`n**Data:** 2025-08-26`n**Status:** Do zrobienia" --label "normal" --label "coordination" --label "assembly" --label "preparation"

gh issue create --title "Zarezerwowanie samochodu" --body "**Zadanie nadrzędne:** Główne zadanie logistyki`n**Notatki:** Bus/van, ubezpieczenie`n**Data:** 2025-08-26`n**Status:** Do zrobienia" --label "normal" --label "logistics" --label "preparation"

gh issue create --title "Przygotowanie szczegółowego harmonogramu przygotowań i montażu wraz z kamieniami milowymi" --body "**Zadanie nadrzędne:** Główne zadanie koordynacji`n**Notatki:** Plan 22–31.08 + bufor`n**Data:** 2025-08-27`n**Status:** Do zrobienia" --label "critical" --label "coordination" --label "preparation"

gh issue create --title "Sprawdzenie stanu zamówionych materiałów i paneli" --body "**Zadanie nadrzędne:** Główne zadanie zakupów`n**Notatki:** Ilość, jakość, zdjęcia`n**Data:** 2025-08-28`n**Status:** Do zrobienia" --label "normal" --label "purchases" --label "preparation"

gh issue create --title "Przygotowanie narzędzi i materiałów do montażu" --body "**Zadanie nadrzędne:** Główne zadanie montażu`n**Notatki:** Lista narzędzi, baterie, śruby`n**Data:** 2025-08-28`n**Status:** Do zrobienia" --label "normal" --label "assembly" --label "preparation"

gh issue create --title "Pakowanie i przygotowanie do wyjazdu" --body "**Zadanie nadrzędne:** Główne zadanie logistyki`n**Notatki:** Etykiety, zabezpieczenie roślin`n**Data:** 2025-08-29`n**Status:** Do zrobienia" --label "normal" --label "logistics" --label "gardening" --label "preparation"

gh issue create --title "Ostateczne potwierdzenie wszystkich szczegółów" --body "**Zadanie nadrzędne:** Główne zadanie koordynacji`n**Notatki:** Klient/noclegi/auto – potwierdzenia`n**Data:** 2025-08-29`n**Status:** Do zrobienia" --label "critical" --label "coordination" --label "preparation"

gh issue create --title "Wyjazd do Kielc" --body "**Zadanie nadrzędne:** Główne zadanie logistyki`n**Notatki:** Załadunek, lista obecności`n**Data:** 2025-08-30`n**Status:** Do zrobienia" --label "critical" --label "logistics" --label "coordination" --label "execution"

gh issue create --title "Rozpoczęcie montażu dekoracji" --body "**Zadanie nadrzędne:** Główne zadanie montażu`n**Notatki:** Panele + podkład`n**Data:** 2025-08-30`n**Status:** Do zrobienia" --label "normal" --label "assembly" --label "gardening" --label "execution"

gh issue create --title "Kontynuacja montażu dekoracji" --body "**Zadanie nadrzędne:** Główne zadanie montażu`n**Notatki:** Kieszenie, tekstylia, rośliny`n**Data:** 2025-08-31`n**Status:** Do zrobienia" --label "normal" --label "assembly" --label "gardening" --label "execution"

gh issue create --title "Sprawdzenie postępów i ewentualne korekty" --body "**Zadanie nadrzędne:** Główne zadanie koordynacji`n**Notatki:** Dokumentacja zdjęciowa`n**Data:** 2025-08-31`n**Status:** Do zrobienia" --label "normal" --label "coordination" --label "execution"

gh issue create --title "Zakończenie montażu dekoracji" --body "**Zadanie nadrzędne:** Główne zadanie montażu`n**Notatki:** Ostatnie poprawki i porządek`n**Data:** 2025-09-01`n**Status:** Do zrobienia" --label "critical" --label "assembly" --label "gardening" --label "completion"

gh issue create --title "Przygotowanie stoisk na targi" --body "**Zadanie nadrzędne:** Główne zadanie montażu`n**Notatki:** Oświetlenie, czystość, ekspozycja`n**Data:** 2025-09-01`n**Status:** Do zrobienia" --label "normal" --label "assembly" --label "gardening" --label "completion"

Write-Host "✅ Główne zadania zostały utworzone!" -ForegroundColor Green

# Utwórz README.md
Write-Host ""
Write-Host "📝 Tworzenie README.md..." -ForegroundColor Cyan

$readmeContent = @"
# 🌿 BWS Kielce Project

System zarządzania projektem dekoracji ogrodowych dla BWS Kielce.

## 📊 Struktura projektu

### Zadania (Issues)
- **Główne zadania**: 21 zadań nadrzędnych
- **Podzadania**: Szczegółowe kroki dla każdego głównego zadania
- **Etykiety**: Priorytet, rola, etap, status

### Etykiety (Labels)

#### Priorytet
- `critical` - Zadania krytyczne
- `high` - Zadania wysokiego priorytetu  
- `normal` - Zadania normalnego priorytetu
- `low` - Zadania niskiego priorytetu

#### Rola
- `coordination` - Zadania koordynacyjne
- `purchases` - Zadania zakupowe
- `logistics` - Zadania logistyczne
- `assembly` - Zadania montażowe
- `gardening` - Zadania ogrodnicze

#### Etap
- `planning` - Etap planowania (22-23.08)
- `preparation` - Etap przygotowań (24-29.08)
- `execution` - Etap wykonania (30-31.08)
- `completion` - Etap zakończenia (01.09)

#### Status
- `blocked` - Zadanie zablokowane
- `waiting` - Oczekujące na akcję
- `ready` - Gotowe do wykonania

## 🎯 Harmonogram

- **22-23.08.2025**: Planowanie
- **24-29.08.2025**: Przygotowania
- **30-31.08.2025**: Wykonanie
- **01.09.2025**: Zakończenie

## 📋 Codzienna checklista

1. Sprawdź zadania z etykietą `critical`
2. Przejrzyj zadania na dziś (według daty)
3. Zaktualizuj status zadań w toku
4. Sprawdź blokady i zależności

## 🔗 Przydatne linki

- [GitHub Project Board](https://github.com/orgs/$username/projects/$projectNumber)
- [Wszystkie zadania](https://github.com/$username/bws-kielce-project/issues)
- [Dokumentacja projektu](link-do-dokumentacji)

## 📞 Kontakt

- **Koordynacja**: koordynacja@projekt.pl
- **Zakupy**: zakupy@projekt.pl
- **Logistyka**: logistyka@projekt.pl
- **Montaż**: montaz@projekt.pl
- **Ogrodnictwo**: ogrodnictwo@projekt.pl
"@

$readmeContent | Out-File -FilePath "README.md" -Encoding UTF8

# Dodaj README do repozytorium
git add README.md
git commit -m "📝 Dodaj README z opisem projektu"
git push origin main

Write-Host ""
Write-Host "🎉 KONFIGURACJA ZAKOŃCZONA POMYŚLNIE!" -ForegroundColor Green
Write-Host "======================================" -ForegroundColor Green
Write-Host ""
Write-Host "✅ Utworzono repozytorium: bws-kielce-project" -ForegroundColor Green
Write-Host "✅ Utworzono projekt GitHub" -ForegroundColor Green
Write-Host "✅ Utworzono wszystkie etykiety" -ForegroundColor Green
Write-Host "✅ Utworzono 21 głównych zadań" -ForegroundColor Green
Write-Host "✅ Utworzono README.md" -ForegroundColor Green
Write-Host ""
Write-Host "🌐 Otwórz projekt w przeglądarce:" -ForegroundColor Cyan
Write-Host "   https://github.com/$username/bws-kielce-project" -ForegroundColor White
Write-Host ""
Write-Host "📊 Otwórz GitHub Project:" -ForegroundColor Cyan
Write-Host "   https://github.com/orgs/$username/projects" -ForegroundColor White
Write-Host ""
Write-Host "🎯 Następne kroki:" -ForegroundColor Yellow
Write-Host "   1. Skonfiguruj kolumny Kanban w GitHub Project" -ForegroundColor White
Write-Host "   2. Dodaj członków zespołu do repozytorium" -ForegroundColor White
Write-Host "   3. Ustaw powiadomienia i automatyzacje" -ForegroundColor White
Write-Host "   4. Rozpocznij pracę nad zadaniami!" -ForegroundColor White
Write-Host ""
Write-Host "🚀 Projekt jest gotowy do użycia!" -ForegroundColor Green
