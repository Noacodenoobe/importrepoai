# 🌿 Plan Projektu BWS Kielce – Hierarchia Zadań z Instrukcjami

## 1. Opracowanie listy zadań z estymacjami
- [ ] Podziel wszystkie zadania główne na mniejsze etapy.
- [ ] Do każdego etapu wpisz czas w roboczogodzinach.
- [ ] Uwzględnij zapas (np. +20%).
- [ ] Przypisz osoby odpowiedzialne.
💡 *Sugestia: użyj prostego Excela/Notion – kolumny: Zadanie | Podzadanie | Czas | Osoba.*

---

## 2. Przydzielenie zasobów (ludzie)
- [ ] Sporządź listę osób (z numerami kontaktowymi).
- [ ] Przypisz role (Zakupy, Logistyka, Montaż, Rośliny, Koordynacja).
- [ ] Sprawdź dostępność każdej osoby w terminie.
💡 *Tip: dobrze mieć 1 osobę rezerwową „w pogotowiu”.*

---

## 3. Zweryfikowanie paneli
- [ ] Sprawdź model i ilość paneli w aloweogrodowe.pl.
- [ ] Porównaj min. 2 alternatywnych dostawców.
- [ ] Zanotuj ceny, czas dostawy, koszty transportu.
- [ ] Potwierdź, czy panele można docinać.
💡 *Zrób zrzut ekranu oferty – unikniesz pomyłek.*

---

## 4. Zamówienie paneli
- [ ] Oblicz liczbę (34 m² + 10–15% zapasu).
- [ ] Złóż zamówienie z dostawą do piątku.
- [ ] Potwierdź pisemnie (mail).
- [ ] Zanotuj nr zamówienia i osobę kontaktową.
⚠️ *Ryzyko: brak dostawy → przygotuj kontakt do alternatywnego sklepu.*

---

## 5. Potwierdzenie specyfikacji materiałów
- [ ] Klej – sprawdź odporność na wilgoć i ciężar.
- [ ] Materiał tekstylny – wybierz próbkę, sprawdź czy łatwy do cięcia.
- [ ] Dykta – minimalna grubość 5 mm.
- [ ] Porównaj 2–3 opcje i wybierz najlepszą.
💡 *Możesz zamówić próbki wcześniej – test na małym kawałku.*

---

## 6. Kieszenie na rośliny
- [ ] Policz potrzebne rośliny → przelicz na kieszenie.
- [ ] Zaprojektuj układ (np. 3 × 5 = 15).
- [ ] Sprawdź, czy są na stanie w sklepie.
- [ ] Zamów min. 2–3 sztuki zapasu.
💡 *Kieszenie warto mieć identyczne – dla spójnego efektu wizualnego.*

---

## 7. Transport roślin
- [ ] Spisz listę roślin (gatunki, ilość, wielkość donic).
- [ ] Przygotuj materiały ochronne: folie, kartony, pianki.
- [ ] Wybierz pojazd z przestrzenią, gdzie rośliny nie ulegną zniszczeniu.
- [ ] Zaplanuj trasę i godziny.
- [ ] Wyznacz kierowcę + pomocnika.
💡 *Podlej rośliny dzień wcześniej – nie w dniu transportu, bo ziemia będzie się rozsypywać.*

---

## 8. Noclegi
- [ ] Policz osoby w zespole.
- [ ] Poszukaj hotelu blisko hali (ul. Zakładowa 1).
- [ ] Zarezerwuj min. 2 pokoje zapasowe (na wypadek zmian).
- [ ] Potwierdź rezerwację i godziny check-in/out.
⚠️ *Sprawdź parking – czy zmieści się bus z materiałami.*

---

## 9. Ludzie do montażu
- [ ] Określ ilu monterów potrzebujesz.
- [ ] Zorganizuj ekipę (np. 2–3 osoby).
- [ ] Podpisz ustne/pisemne porozumienie.
- [ ] Przypisz konkretne zadania (np. panele, rośliny, logistyka).
💡 *Dobrze, żeby jedna osoba miała doświadczenie w montażu konstrukcji.*

---

## 10. Samochód
- [ ] Określ wymagania: ładowność, ilość miejsc.
- [ ] Zarezerwuj busa/auta.
- [ ] Potwierdź dostępność na 30 sierpnia.
- [ ] Zanotuj dane kontaktowe wypożyczalni.
⚠️ *Sprawdź ubezpieczenie i warunki zwrotu.*

---

## 11. Harmonogram z kamieniami milowymi
- [ ] Rozpisz każdy dzień (22–31 sierpnia).
- [ ] Oznacz kamienie: zamówienia, transport, montaż, odbiór klienta.
- [ ] Zostaw bufor czasowy (min. 1 dzień zapasu).
💡 *Najlepiej powiesić harmonogram na tablicy – łatwa kontrola.*

---

## 12. Kontrola dostaw
- [ ] Sprawdź ilość i stan po dostawie.
- [ ] Zrób zdjęcia dla dokumentacji.
- [ ] Zgłoś braki natychmiast.
💡 *Zapisuj kto przyjął dostawę – odpowiedzialność.*

---

## 13. Przygotowanie narzędzi
- [ ] Wkrętarki, bity, noże, miarki, drabiny, poziomica.
- [ ] Sprawdź stan techniczny i baterie.
- [ ] Przygotuj zapasowe akcesoria (śruby, taśmy).
💡 *Lista narzędzi + check przy pakowaniu.*

---

## 14. Pakowanie i przygotowanie
- [ ] Spakuj materiały w kartony.
- [ ] Oznacz etykietami (np. Panele A, Klej B).
- [ ] Zabezpiecz rośliny (folia, kartony).
- [ ] Sprawdź wagę i objętość (czy zmieści się w aucie).
💡 *Dobrze spakowane = szybki montaż.*

---

## 15. Ostateczne potwierdzenie
- [ ] Zadzwoń do klienta – potwierdź zakres i termin.
- [ ] Sprawdź rezerwacje noclegów i auta.
- [ ] Wyślij zespołowi finalny plan w PDF.
⚠️ *Bez tego kroku ryzyko chaosu w dniu wyjazdu.*

---

## 16. Wyjazd do Kielc
- [ ] Spotkanie o ustalonej godzinie.
- [ ] Załadunek materiałów i narzędzi.
- [ ] Sprawdzenie obecności całego zespołu.
- [ ] Wyjazd zgodnie z planem.
💡 *Dobrze mieć listę kontrolną „przed startem”.*

---

## 17–20. Montaż dekoracji
**Etap 1 – Rozładunek**
- [ ] Rozładuj panele i materiały.
- [ ] Ustaw stanowiska pracy.

**Etap 2 – Montaż konstrukcji**
- [ ] Przytwierdź panele i podkład.
- [ ] Sprawdź stabilność.

**Etap 3 – Rośliny i wykończenie**
- [ ] Zamocuj kieszenie i tekstylia.
- [ ] Posadź rośliny.
- [ ] Sprawdź efekt wizualny (360°).

**Etap 4 – Kontrola**
- [ ] Skontroluj estetykę i stabilność.
- [ ] Popraw ewentualne braki.
💡 *Dokumentuj zdjęciami – to materiał dla klienta i portfolio.*

---

## 21. Przygotowanie stoisk
- [ ] Rozstaw rośliny dodatkowe (jeśli są).
- [ ] Posprzątaj teren wokół.
- [ ] Sprawdź oświetlenie i dostęp do prądu.
- [ ] Zrób finalne zdjęcia.
💡 *Ostatni szlif decyduje o wrażeniu klienta.*

---

# ✅ Dodatkowe sugestie
- **Komunikacja**: ustalić 1 osobę odpowiedzialną za kontakt z klientem i dostawcami.  
- **Plan awaryjny**: alternatywny dostawca paneli, dodatkowy samochód w rezerwie.  
- **Bezpieczeństwo**: apteczka, rękawice, kask przy montażu na wysokości.  
- **Dokumentacja**: zdjęcia na każdym etapie (dowód wykonania + promocja).  
- **Check-lista codzienna**: rano – zadania do wykonania, wieczorem – podsumowanie.  
