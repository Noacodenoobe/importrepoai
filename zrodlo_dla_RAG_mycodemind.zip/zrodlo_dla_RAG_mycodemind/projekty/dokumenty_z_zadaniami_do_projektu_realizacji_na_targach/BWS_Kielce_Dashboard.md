
# 🌿 BWS Kielce – Dashboard

Centralny panel zarządzania projektem BWS Kielce.  
W tym miejscu znajdziesz wszystkie zadania, zasoby, zakupy i narzędzia, a także checklisty i harmonogram.

---

## 📊 Zadania

👉 Tutaj wstaw **Linked Database** do bazy: `Zadania Projektowe`  
Po dodaniu bazy utwórz widoki:

- **Kanban – Status**
  - Group by: `Status`
  - Sort by: `Date`
- **Timeline – Etapy**
  - View type: Timeline
  - Timeline based on: `Date`
  - Group by: `Parent`
- **Tabela Hierarchiczna**
  - Group by: `Parent`
  - Columns: `Task, Parent, Status, Date, Priority, Role`

💡 Komentarz: Każde zadanie powinno mieć powiązania (relation) z zasobami, zakupami i narzędziami.

---

## 🧑‍🤝‍🧑 Zasoby

👉 Wstaw **Linked Database** do bazy: `Zasoby`  
Proponowane widoki:

- **Tabela**
  - Kolumny: `Osoba/Grupa, Rola, Kontakt, Status`
- **Dostępność**
  - Filtr: `Status = Dostępny`

💡 Komentarz: Po kliknięciu w osobę zobaczysz jej przypisane zadania (relation z Zadaniami).

---

## 🛒 Zakupy

👉 Wstaw **Linked Database** do bazy: `Zakupy`  
Proponowane widoki:

- **Tabela**
  - Kolumny: `Materiał, Ilość, Dostawca, Status`
- **Kanban**
  - Group by: `Status`
  - Kolumny: `Do zamówienia / Rezerwacja / Zamówione`
- **Koszty**
  - Jeśli dodasz kolumnę `Cena`, włącz SUM w stopce tabeli.

💡 Komentarz: Relation z Zadaniami pozwoli zobaczyć, w których etapach używane są dane materiały.

---

## 🛠️ Narzędzia

👉 Wstaw **Linked Database** do bazy: `Narzędzia`  
Proponowane widoki:

- **Checklista**
  - Filtr: `Stan techniczny ≠ Sprawna`
- **Pełna lista**
  - Kolumny: `Narzędzie, Stan techniczny, Baterie, Przypisane do`

💡 Komentarz: Relation z Zadaniami wskaże, które zadania wymagają danego narzędzia.

---

## ✅ Codzienna checklista

👉 Wstaw **Linked Database** do bazy: `Zadania Projektowe`  
Utwórz widok „Dzienny” z filtrami:

- `Date = Today`
- `Priority = Krytyczne`
- `Status ≠ Zrobione`

Dodatkowo dodaj:

- **Linked view do Narzędzi** → filtr: `Stan techniczny ≠ Sprawna`
- **Linked view do Zakupów** → filtr: `Status ≠ Zamówione`

💡 Komentarz: Dzięki temu rano masz automatycznie listę rzeczy do sprawdzenia.

---

## 🔗 Linki

Dodaj tutaj linki do:
- 📂 Google Drive (dokumentacja)
- 📑 PDF z planem projektu
- 🗂️ Inne narzędzia (np. Slack, Asana, Trello)

---

# 📌 Jak skonfigurować RELACJE

1. W bazie **Zadania** dodaj kolumny typu Relation:
   - Relation → Zasoby (kto odpowiada)
   - Relation → Zakupy (jakie materiały)
   - Relation → Narzędzia (jakie sprzęty)
2. Włącz opcję „Show on other database”, aby relacja działała dwustronnie.
3. Po tym każda karta Zadania będzie pokazywać:
   - Osobę odpowiedzialną
   - Wymagane materiały
   - Potrzebne narzędzia

---

# 🎯 Efekt końcowy

- **Dashboard** zbiera wszystko w jednym miejscu.  
- W **Zadaniach** widzisz hierarchię, status i harmonogram.  
- W **Zasobach** kontrolujesz dostępność ludzi.  
- W **Zakupach** masz pełen przegląd statusu zamówień.  
- W **Narzędziach** checklistę sprzętu.  
- W **Codziennej checkliście** szybki przegląd krytycznych działań.

