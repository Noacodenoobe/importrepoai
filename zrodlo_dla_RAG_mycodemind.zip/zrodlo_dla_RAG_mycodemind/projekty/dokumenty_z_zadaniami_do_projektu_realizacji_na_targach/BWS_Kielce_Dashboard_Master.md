
# 🌿 BWS Kielce – Dashboard Master

Centralny panel projektu BWS Kielce – pełne centrum dowodzenia, łączące workflow, zadania, harmonogram, zasoby, zakupy i narzędzia.

---

## 🖼️ Workflow – mapa procesu
👉 Wstaw tutaj obraz PNG `BWS_Kielce_Workflow_21etapow.png` (komenda `/image` w Notion).

- Obraz pokazuje 21 etapów projektu krok po kroku.
- Dzięki niemu masz wizualną mapę procesu.

---

## 📑 Workflow – interaktywna checklista
👉 Wklej tutaj zawartość z pliku `BWS_Kielce_Workflow_21etapow.md`

- Każdy etap ma checkboxy i komentarze.
- Możesz je łączyć z Zadaniami przez **Relation**.

---

## 📊 Zadania Projektowe (Linked Database)
👉 Dodaj tutaj **Linked Database** → `Zadania Projektowe`

### Widoki:
- **Kanban (Status)** → Group by: Status
- **Timeline (Etapy)** → Date jako oś czasu, Group by Parent
- **Hierarchia** → Group by Parent (widok pełnej struktury)

💡 Komentarz: W kolumnach widoczne `Task, Parent, Status, Priority, Role, Date`.  
Dodaj relation z: **Zasoby, Zakupy, Narzędzia, Harmonogram**.

---

## 📅 Harmonogram (Linked Database)
👉 Dodaj tutaj **Linked Database** → `Harmonogram`

### Widoki:
- **Timeline** → Date jako oś czasu, Group by Parent, Color by Priority
- **Tabela zależności** → kolumny: Task, Parent, Dependency, Owner

💡 Komentarz: używaj tego widoku do kontroli kolejności i zależności między zadaniami.

---

## 🧑‍🤝‍🧑 Zasoby (Linked Database)
👉 Dodaj tutaj **Linked Database** → `Zasoby`

### Widoki:
- **Tabela** → Osoba/Grupa, Rola, Kontakt, Status
- **Dostępność** → filtr: Status = Dostępny

💡 Komentarz: relacja z Zadaniami pozwala zobaczyć obciążenie zespołu.

---

## 🛒 Zakupy (Linked Database)
👉 Dodaj tutaj **Linked Database** → `Zakupy`

### Widoki:
- **Kanban (Status)** → Group by Status (Do zamówienia / Rezerwacja / Zamówione)
- **Tabela kosztów** → dodaj kolumnę Cena, włącz SUM

💡 Komentarz: relacja z Zadaniami pokaże, które materiały są przypisane do konkretnych etapów.

---

## 🛠 Narzędzia (Linked Database)
👉 Dodaj tutaj **Linked Database** → `Narzędzia`

### Widoki:
- **Checklista** → filtr: Stan techniczny ≠ Sprawna
- **Pełna lista** → wszystkie narzędzia z przypisaniem do ról

💡 Komentarz: relacja z Zadaniami pozwala sprawdzić, co trzeba przygotować do danego etapu.

---

## ✅ Codzienna Checklista
👉 Dodaj tutaj **Linked Database** → `Zadania Projektowe`

### Widok Dzienny:
- Filtr: Date = Today
- Filtr: Priority = Krytyczne
- Filtr: Status ≠ Zrobione

Dodatkowo dodaj:
- **Linked view do Narzędzi** → filtr: Stan techniczny ≠ Sprawna
- **Linked view do Zakupów** → filtr: Status ≠ Zamówione

💡 Komentarz: otwierasz rano Dashboard → masz listę najważniejszych działań na dziś.

---

## 📊 Raporty i wskaźniki
👉 Utwórz widok **Board lub Table** z agregatami.

- **Zadania otwarte** → filtr: Status ≠ Zrobione → count
- **Zadania krytyczne** → filtr: Priority = Krytyczne → count
- **Zakupy w toku** → filtr: Status ≠ Zamówione → count
- **Narzędzia do sprawdzenia** → filtr: Stan techniczny ≠ Sprawna → count

💡 Komentarz: możesz dodać licznik zadań w roli „Progress bar” np. % ukończonych.

---

# 🔗 Powiązania (Relations)
Wszystkie bazy powinny być połączone relacjami:

- Zadania ↔ Zasoby (kto odpowiada)
- Zadania ↔ Zakupy (materiały)
- Zadania ↔ Narzędzia (sprzęt)
- Zadania ↔ Harmonogram (termin i zależności)

Dzięki temu w karcie zadania widzisz cały kontekst: osobę, materiały, narzędzia i termin.

---

# 🎯 Efekt końcowy
Ten **Dashboard Master** zbiera wszystko w jednym miejscu:  
- **Mapa workflow (PNG)** + **checklista etapów (MD)**  
- **Zadania, Harmonogram, Zasoby, Zakupy, Narzędzia** w jednym panelu  
- **Codzienna checklista** do odpraw i bieżącej pracy  
- **Raporty i wskaźniki** monitorujące status projektu  

