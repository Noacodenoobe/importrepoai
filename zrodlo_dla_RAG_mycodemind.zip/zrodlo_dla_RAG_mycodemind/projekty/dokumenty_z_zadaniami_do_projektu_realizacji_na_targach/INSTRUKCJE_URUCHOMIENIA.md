# 🚀 Instrukcje uruchomienia BWS Kielce Project

## 📋 Wymagania wstępne

### 1. Zainstaluj GitHub CLI
```bash
# Windows (PowerShell)
winget install GitHub.cli

# macOS
brew install gh

# Linux (Ubuntu/Debian)
curl -fsSL https://cli.github.com/packages/githubcli-archive-keyring.gpg | sudo dd of=/usr/share/keyrings/githubcli-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/githubcli-archive-keyring.gpg] https://cli.github.com/packages stable main" | sudo tee /etc/apt/sources.list.d/github-cli.list > /dev/null
sudo apt update
sudo apt install gh
```

### 2. Zaloguj się do GitHub CLI
```bash
gh auth login
```

## 🎯 Uruchomienie automatycznej konfiguracji

### Opcja 1: Uruchomienie głównego skryptu (ZALECANE)
```bash
# Nadaj uprawnienia wykonywania
chmod +x setup_bws_kielce_project.sh

# Uruchom automatyczną konfigurację
./setup_bws_kielce_project.sh
```

### Opcja 2: Uruchomienie kroków pojedynczo

#### Krok 1: Utwórz repozytorium i projekt
```bash
chmod +x step1_create_repository_and_project.sh
./step1_create_repository_and_project.sh
```

#### Krok 2: Utwórz etykiety
```bash
chmod +x step2_create_labels.sh
./step2_create_labels.sh
```

#### Krok 3: Utwórz główne zadania
```bash
chmod +x step3_create_issues.sh
./step3_create_issues.sh
```

#### Krok 3B: Utwórz podzadania
```bash
chmod +x step3b_create_subtasks.sh
./step3b_create_subtasks.sh
```

## 📊 Co zostanie utworzone

### Repozytorium
- **Nazwa**: `bws-kielce-project`
- **Typ**: Prywatne
- **Opis**: BWS Kielce Project - System zarządzania projektem dekoracji ogrodowych

### Projekt GitHub
- **Nazwa**: "BWS Kielce Project"
- **Typ**: Board (Kanban)
- **Połączony z**: Repozytorium bws-kielce-project

### Etykiety (Labels)
- **Priorytet**: critical, high, normal, low
- **Rola**: coordination, purchases, logistics, assembly, gardening
- **Etap**: planning, preparation, execution, completion
- **Status**: blocked, waiting, ready
- **Dodatkowe**: milestone, documentation, quality-check, client-communication

### Zadania (Issues)
- **Główne zadania**: 21 zadań nadrzędnych
- **Podzadania**: 65 szczegółowych kroków
- **Łącznie**: 86 zadań

## 🎯 Struktura zadań

### Główne zadania (21)
1. Opracowanie listy zadań z estymacjami
2. Przydzielenie zasobów
3. Zweryfikowanie dostępności i cen paneli
4. Określenie wymaganą liczbę paneli
5. Potwierdzenie specyfikacji materiałów
6. Zweryfikowanie finalnej liczby kieszeni
7. Przygotowanie planu transportu roślin
8. Zorganizowanie noclegów
9. Dogadanie ludzi do montażu
10. Zarezerwowanie samochodu
11. Przygotowanie harmonogramu
12. Sprawdzenie stanu zamówionych materiałów
13. Przygotowanie narzędzi
14. Pakowanie i przygotowanie
15. Ostateczne potwierdzenie
16. Wyjazd do Kielc
17. Rozpoczęcie montażu
18. Kontynuacja montażu
19. Sprawdzenie postępów
20. Zakończenie montażu
21. Przygotowanie stoisk

### Podzadania (65)
Każde główne zadanie ma 2-4 podzadania z szczegółowymi krokami.

## 🔧 Konfiguracja po uruchomieniu

### 1. Skonfiguruj kolumny Kanban
1. Otwórz GitHub Project
2. Przejdź do ustawień projektu
3. Dodaj kolumny:
   - 📋 Backlog
   - 🎯 To Do
   - 🔄 In Progress
   - ✅ Done
   - 🚀 Deployed

### 2. Dodaj członków zespołu
```bash
# Dodaj użytkowników do repozytorium
gh repo add-collaborator bws-kielce-project USERNAME --permission write
```

### 3. Skonfiguruj automatyzacje
1. W GitHub Project przejdź do "Automation"
2. Włącz automatyczne przenoszenie zadań
3. Ustaw powiadomienia o deadline'ach

### 4. Dodaj szablony zadań
Utwórz pliki w `.github/ISSUE_TEMPLATE/`:
- `bug_report.md`
- `feature_request.md`
- `task_template.md`

## 📱 Przydatne komendy

### Sprawdź status projektu
```bash
# Lista wszystkich zadań
gh issue list --repo bws-kielce-project

# Zadania z etykietą critical
gh issue list --repo bws-kielce-project --label critical

# Zadania dla konkretnej osoby
gh issue list --repo bws-kielce-project --assignee USERNAME
```

### Aktualizuj zadania
```bash
# Zmień status zadania
gh issue edit ISSUE_NUMBER --add-label "in-progress"

# Przypisz zadanie
gh issue edit ISSUE_NUMBER --add-assignee USERNAME

# Dodaj komentarz
gh issue comment ISSUE_NUMBER --body "Zadanie rozpoczęte"
```

### Eksportuj dane
```bash
# Eksportuj wszystkie zadania do CSV
gh issue list --repo bws-kielce-project --json number,title,labels,assignees,state,createdAt --jq '.[] | [.number, .title, (.labels | map(.name) | join(",")), (.assignees | map(.login) | join(",")), .state, .createdAt] | @csv' > issues.csv
```

## 🆘 Rozwiązywanie problemów

### Problem: "Repository already exists"
```bash
# Usuń istniejące repozytorium
gh repo delete bws-kielce-project --yes
```

### Problem: "Permission denied"
```bash
# Sprawdź uprawnienia
gh auth status

# Zaloguj się ponownie
gh auth login
```

### Problem: "Command not found"
```bash
# Sprawdź czy GitHub CLI jest zainstalowany
gh --version

# Jeśli nie, zainstaluj ponownie
```

## 📞 Wsparcie

W przypadku problemów:
1. Sprawdź logi błędów w terminalu
2. Upewnij się, że masz odpowiednie uprawnienia na GitHub
3. Sprawdź czy wszystkie wymagania są spełnione
4. Skontaktuj się z administratorem projektu

## 🎉 Gotowe!

Po pomyślnym uruchomieniu będziesz mieć:
- ✅ Kompletnie skonfigurowane repozytorium
- ✅ Projekt GitHub z wszystkimi zadaniami
- ✅ System etykiet i kategoryzacji
- ✅ Hierarchiczną strukturę zadań
- ✅ Automatyczną dokumentację

**Projekt jest gotowy do użycia! 🚀**
