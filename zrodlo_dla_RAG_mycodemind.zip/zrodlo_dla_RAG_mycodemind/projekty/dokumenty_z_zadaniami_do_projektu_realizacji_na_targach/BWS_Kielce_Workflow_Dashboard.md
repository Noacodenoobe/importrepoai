
# 🌿 BWS Kielce – Workflow (pełna strona)

Ta strona łączy **schemat graficzny (workflow PNG)** oraz **interaktywną checklistę (Markdown)**, 
abyś miał pełny podgląd i kontrolę nad wszystkimi 21 etapami projektu.

---

## 🖼️ Schemat graficzny (Workflow 21 etapów)

👉 Wklej tutaj obraz PNG:
`BWS_Kielce_Workflow_21etapow.png`

- W Notion użyj `/image` i wgraj plik PNG.
- Ten schemat pokazuje przebieg projektu od Etapu 1 do Etapu 21.

---

## 📑 Interaktywna lista kroków (21 etapów)

Importuj poniższą sekcję jako checklistę, a następnie powiąż każdy etap z bazą **Zadania Projektowe**.

### 01. Opracowanie listy zadań
- [ ] Podziel zadania główne na etapy
- [ ] Oszacuj czas i dodaj zapas (+20%)
- [ ] Przypisz osoby odpowiedzialne

### 02. Przydzielenie zasobów
- [ ] Sporządź listę osób (kontakty)
- [ ] Przypisz role (zakupy, montaż, rośliny, koordynacja)
- [ ] Zadbaj o dostępność ludzi

### 03. Zweryfikowanie paneli
- [ ] Sprawdź modele i ilości paneli
- [ ] Porównaj min. 2 dostawców
- [ ] Zanotuj ceny i koszty transportu
- [ ] Upewnij się, że panele można dociąć

### 04. Zamówienie paneli
- [ ] Oblicz ilości (34m² + 10–15% zapasu)
- [ ] Złóż zamówienie z dostawą
- [ ] Potwierdź pisemnie

### 05. Potwierdzenie specyfikacji materiałów
- [ ] Klej – sprawdź odporność na wilgoć
- [ ] Tekstylia – wybierz i przetestuj
- [ ] Dykta – minimalna grubość 5mm

### 06. Kieszenie na rośliny
- [ ] Policz rośliny na kieszenie
- [ ] Ustal układ (np. 3x5)
- [ ] Zamów rośliny w sklepie

### 07. Transport roślin
- [ ] Sporządź listę gatunków i ilości
- [ ] Przygotuj materiały ochronne
- [ ] Wybierz pojazd z przestrzenią
- [ ] Zaplanuj trasę i godzinę

### 08. Noclegi
- [ ] Zarezerwuj hotel blisko hali
- [ ] Przygotuj min. 2 pokoje zapasowe
- [ ] Potwierdź godziny check-in/out

### 09. Ludzie do montażu
- [ ] Określ ilu monterów potrzebujesz
- [ ] Zorganizuj ekipę (2–3 osoby)
- [ ] Podpisz umowę/pisemne ustalenie

### 10. Samochód
- [ ] Określ wymagania (ładowność)
- [ ] Zarezerwuj bus/auto
- [ ] Potwierdź dostępność
- [ ] Zanotuj dane kontaktowe

### 11. Harmonogram
- [ ] Rozpisz każdy dzień (22–31 sierpnia)
- [ ] Uwzględnij bufor 1 dzień zapasu
- [ ] Najlepiej powieś harmonogram na tablicy

### 12. Kontrola dostaw
- [ ] Sprawdź ilości i stan po dostawie
- [ ] Zrób zdjęcia dokumentacji
- [ ] Zgłoś braki natychmiast

### 13. Przygotowanie narzędzi
- [ ] Sprawdź wkrętarki, bity, noże, miarki
- [ ] Skontroluj stan techniczny i baterie
- [ ] Przygotuj zapasowe akcesoria

### 14. Pakowanie
- [ ] Spakuj materiały do kartonów
- [ ] Oznacz etykietami
- [ ] Zabezpiecz rośliny (folia, kartony)
- [ ] Sprawdź wagę i objętość

### 15. Ostateczne potwierdzenie
- [ ] Zadzwoń do klienta – potwierdź zakres i termin
- [ ] Sprawdź rezerwacje noclegów i auta
- [ ] Wyślij finalny plan zespołowi

### 16. Wyjazd do Kielc
- [ ] Spotkanie w ustalonej godzinie
- [ ] Załaduj materiały i narzędzia
- [ ] Sprawdź obecność całego zespołu

### 17. Montaż – Rozładunek
- [ ] Rozładuj panele i materiały
- [ ] Ustaw stanowisko pracy

### 18. Montaż – Konstrukcja
- [ ] Przymocuj panele i podkład
- [ ] Sprawdź stabilność

### 19. Montaż – Rośliny i wykończenie
- [ ] Zamocuj kieszenie
- [ ] Posadź rośliny
- [ ] Sprawdź efekt wizualny (360°)

### 20. Montaż – Kontrola
- [ ] Skontroluj estetykę i stabilność
- [ ] Popraw ewentualne braki
- [ ] Udokumentuj zdjęciami

### 21. Przygotowanie stoisk
- [ ] Rozstaw rośliny dodatkowe
- [ ] Posprzątaj teren wokół
- [ ] Sprawdź oświetlenie i dostęp do prądu
- [ ] Zrób zdjęcia finalne

---

## 🔗 Powiązania z bazami
- **Zadania Projektowe** – powiązania etapów z konkretnymi taskami
- **Zasoby** – kto odpowiada za dany etap
- **Zakupy** – jakie materiały przypisane do etapu
- **Narzędzia** – sprzęty niezbędne w danym etapie
- **Harmonogram** – terminy i zależności

💡 Dzięki relacjom możesz kliknąć w etap i od razu zobaczyć ludzi, materiały i sprzęt powiązany z tym zadaniem.

---

# 🎯 Efekt końcowy
Ta strona to centrum pracy nad projektem: masz **workflow graficzny (PNG)** oraz **interaktywną checklistę (MD)**, powiązaną z bazami danych.

