# Raport różnic: Wersja Pro vs Wersja Bazowa (BWS Stack)

Poniższy raport zestawia różnice między obecną wersją bazową stacka a "wersją Pro" opisaną w `materiały projektowe systemu/wersjapro.txt`. Zawiera tabelę porównawczą oraz konkretne rekomendacje wdrożeniowe.

## Tabela różnic (wysoki poziom)

| Obszar | Wersja bazowa | Wersja Pro | Co zyskujesz | Co zrobić, aby wdrożyć Pro |
|---|---|---|---|---|
| Modele LLM (inferencja) | Ollama: `llama2:7b/13b` (wg env) | `llama3.1:8b`, `qwen2.5:7b/14b` + opcjonalnie „Bielik” (PL) | Lepsza jakość po polsku, szybsze odpowiedzi (7–8B), stabilność | Dodać do `scripts/pull_models.sh` linie dla `llama3.1:8b` i `qwen2.5:7b`; (opcjonalnie) przygotować Modelfile i `ollama create bielik:7b` |
| Embedding | `nomic-embed-text:latest` | Bez zmian (zalecane pozostawić) | Spójne wektory do Qdrant | Brak działań lub ewentualne testy alternatyw |
| AI Bridge (API) | `/health`, `/embed`, `/ingest`, `/search` | + `/generate` (sugerowane) | Jedno spójne API (retry, timeouts), mniej awarii | Dodać endpoint `/generate` w `services/ai-bridge` i przełączyć n8n na AI Bridge |
| n8n – workflowy | `escalation_v2`, `materials_unlock_v2` | + PL Pack: QA checklist, Raport Dzienny, Polish QA (LLM) | Automatyzacje w PL, wygoda | Zaimportować PL workflowy, ustawić Credentials, sprawdzić mapping pól |
| MCP (Cursor) | Placeholdery MCP w config | Snippety Notion (relacje: „Blokuje”, „Zależy od”, „Osoba…”) | Szybkie akcje bez klikania | Zaimplementować minimalny Notion MCP (update/retrieve/search) i dodać narzędzia |
| Reverse proxy / HTTPS | Lokalnie (porty expose) | Caddy z TLS + basicauth + IP limit (opcjonalnie) | Bezpieczny dostęp publiczny | Przygotować Caddyfile, DNS, ograniczyć bezpośrednie porty Dockera |
| Observability | Skrypty health | + metryki, rate‑limit | Szybsze diagnozy, odporność | Metryki w AI Bridge, rate‑limit w Caddy |
| Sprzęt / tuning | Ogólne | Profil pod RTX 5080 16 GB (7–13B; quant) | Wydajność i stabilność | Dobrać model/quant (np. Q4_K_M) wg VRAM |
| Schemat Notion | EN nazwy, podstawowe pola | + pola PL (np. `QA_Dodane?`, formuły `Opóźnione?`) | Bogatsze raporty PL | Dodać właściwości w bazach Notion i dopasować workflow |
| Konfiguracja n8n | Podstawowa | Propagacja NOTION_* do kontenera, Credentials po nazwie | Stabilność po imporcie | Dodać env do `n8n.environment`, restart i przypiąć Credentials |

## Rozwinięcia i rekomendacje

### 1) Modele i wydajność (LLM)
- Rekomendacje: `llama3.1:8b` (uniwersalny, PL‑friendly), `qwen2.5:7b` (szybki, wielojęzyczny). Opcjonalnie „Bielik” (PL) przez Modelfile/gguf.
- Działania:
  - W `scripts/pull_models.sh` dodaj (pamiętaj o separatorze `|`):
    ```bash
    "llama3.1:8b|General purpose PL-friendly"
    "qwen2.5:7b|Fast, multilingual, good in PL"
    # opcjonalnie po przygotowaniu Modelfile
    "bielik:7b|Polish-focused (via Modelfile)"
    ```
  - (Opcjonalnie) Modelfile dla „Bielik”:
    ```
    FROM ./bielik-7b.Q4_K_M.gguf
    PARAMETER temperature 0.3
    PARAMETER top_p 0.9
    TEMPLATE """{{ .Prompt }}"""
    ```
    Następnie: `ollama create bielik:7b -f Modelfile`.

### 2) AI Bridge – dodanie `/generate`
- Dlaczego: spójne miejsce do komunikacji z LLM zamiast bezpośrednio do `ollama:11434` w wielu node’ach n8n.
- Działania: dodać endpoint `POST /generate` (parametry: `model`, `prompt`, `options`) i forward do `OLLAMA_HOST/api/generate`; ujednolicić timeouty i retry.

### 3) n8n – PL Pack (QA, Raport, Polish QA)
- Import po zapisaniu JSON do pliku; po imporcie ustaw Credentials Notion po NAZWIE (ID różnią się między instancjami).
- Pola Notion (PL) do wprowadzenia: `QA_Dodane?` (checkbox), `Opóźnione?` (formula), `Status` (select), `Termin` (date) – zgodnie z użyciem w workflowach.
- LLM node: docelowo przełączyć na `http://ai-bridge:8000/generate`.

### 4) MCP – Notion (snippety)
- Snippety (ustaw relacje „Blokuje” / „Zależy od”, przypisz „Osoba Odpowiedzialna”) przyspieszają pracę. Zaimplementować prosty MCP server Notion (Node/TS lub Python), expose narzędzia: `pages.update`, `pages.retrieve`, `search` i wpiąć snippety.

### 5) Reverse proxy i bezpieczeństwo
- Caddyfile: TLS (Let’s Encrypt), `basicauth` dla publicznego n8n, `header_up X-Forwarded-Proto {scheme}`, `encode zstd gzip`, opcjonalnie whitelist IP i rate‑limit.
- Ograniczyć wystawione porty Dockera – publicznie tylko przez Caddy.

### 6) Observability
- Dodać metryki (np. Prometheus) do AI Bridge i ewentualnie logi strukturalne; dzięki temu szybciej widać błędy i przeciążenia.

### 7) Notion – spójność nazw
- Jeśli przechodzisz na nazwy pól po polsku, trzymaj je konsekwentnie (Status, QA_Dodane?, Zablokowane, Termin…). Workflowy muszą mieć zgodne nazwy właściwości.

### 8) Konfiguracja n8n – env i Credentials
- W `docker-compose.yml` → `n8n.environment` dodaj:
  ```yaml
  - NOTION_API_KEY=${NOTION_API_KEY}
  - NOTION_DATABASE_ID_TASKS=${NOTION_DATABASE_ID_TASKS}
  - NOTION_DATABASE_ID_MATERIALS=${NOTION_DATABASE_ID_MATERIALS}
  - NOTION_DATABASE_ID_RISKS=${NOTION_DATABASE_ID_RISKS}
  - NOTION_DATABASE_ID_TEAM=${NOTION_DATABASE_ID_TEAM}
  ```
- Po imporcie workflowów przypnij Credentials Notion po NAZWIE.

## Checklista wdrożenia Pro
- [ ] Uzupełnij `.env` (możesz skopiować `env.suggested` → `.env` i podmienić `CHANGE_ME`).
- [ ] Dopisz modele w `scripts/pull_models.sh` (`llama3.1:8b`, `qwen2.5:7b`; opcjonalnie `bielik:7b`) i `make pull-models`.
- [ ] Dodaj `/generate` w AI Bridge i przełącz LLM node’y n8n na `ai-bridge`.
- [ ] Dodaj NOTION_* do `n8n.environment` w `docker-compose.yml` i `make restart`.
- [ ] Utwórz wymagane właściwości w bazach Notion (PL) i aktywuj workflowy PL.
- [ ] (Publicznie) Skonfiguruj Caddy + DNS; odetnij bezpośrednie porty.
- [ ] Dodaj metryki/observability i (opcjonalnie) rate‑limit.
